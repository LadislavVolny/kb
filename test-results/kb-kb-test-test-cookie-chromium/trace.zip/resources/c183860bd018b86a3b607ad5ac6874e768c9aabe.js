function persooAddActions(document, window, persoo){
    persoo.actionsJSLoaded = true
    persoo.locations = {
        "scenario_defaultScenario": {
            "class": "PersonalizedBox",
            "name": "Default recommedation for tests only",
            "config": {
                "onUrl": ".*",
                "onPageType": "email",
                "selectorType": "query",
                "selectorValue": "#persooDefaultLocation",
                "insertMode": "replace",
                "noTimeLimits": false
            }
        },
        "f5b94bcfecbe44179d2fc1d375a86fd4": {
            "class": "PersonalizedBox",
            "name": "Autocomplete location general (M)",
            "config": {
                "onUrl": ".*",
                "onPageType": "all",
                "selectorType": "query",
                "selectorValue": "#p_lt_WebPartZone13_HiddenComponents_WebPartZone_WebPartZone_zone_SmartSearchBox_pnlSearch",
                "insertMode": "replace",
                "noTimeLimits": true
            }
        },
        "d337e471b4054a98a4f62a53827e5e68": {
            "class": "PersonalizedBox",
            "name": "Autocomplete demo (M)",
            "config": {
                "onUrl": ".*",
                "onPageType": "all",
                "selectorType": "query",
                "selectorValue": ".menu-common__navigation ~ .menu-common__divider",
                "insertMode": "prepend",
                "noTimeLimits": true
            }
        },
        "f6aa3e422fe44dfa9bdf8dfb5ae1f0f1": {
            "class": "PersonalizedBox",
            "name": "Search results location (M)",
            "config": {
                "onUrl": ".*",
                "onPageType": "search",
                "selectorType": "query",
                "selectorValue": "#persoo-hledani",
                "insertMode": "replace",
                "noTimeLimits": true
            }
        },
        "b3a09c994e6547d5ae1363eea233ccd4": {
            "class": "PersonalizedBox",
            "name": "Autocomplete location podpora (M)",
            "config": {
                "onUrl": ".*\\/cs\\/podpora.*",
                "onPageType": "all",
                "selectorType": "query",
                "selectorValue": "#p_lt_WebPartZone8_zoneContent_contentPH_p_lt_WebPartZone3_zoneContentTop_KB_ActumSearch_searchInputCnt",
                "insertMode": "replace",
                "noTimeLimits": true
            }
        }
    }
    persoo.pluginsConfig = {
        "report-statistics": {
            "sendEvents": false,
            "sendGroupEvents": true
        },
        "google-analytics": {
            "gaVersion": "ga",
            "tagDelimeter": "|",
            "valueDelimeter": ":",
            "gaDebugMode": "off",
            "useGTMTracker": true,
            "statsHandler": "default"
        }
    }
    persoo.actions = persoo.actions || {};
    console.log('Persoo deb. update - 0.3');
    /*
    function createCustomScript() {
    	var script = document.createElement('script');
        script.src = '//scripts.persoo.cz/feqeo4qf12vac4i2srq29i1o/test/persoo-ui.js';
        script.type = 'text/javascript';
        document.body.appendChild(script);
        console.log('tag created');
    }
    
    window.addEventListener('load', createCustomScript);
    */
     function mountOriginalSearchImpression(urlSearchParam, cssSelector) { persoo(function () { setTimeout(function () { window.persoo.on("DOMContentLoaded", function () { var searchQuery = null; var urlParams = document.location.search.substring(1); if (urlParams.match(urlSearchParam)) { var vars = urlParams.split("&"); for (var i = 0; i < vars.length; i++) { var pair = vars[i].split("="); if (pair[0] == urlSearchParam) { searchQuery = pair[1] || null; break; } } var searchResultsCount = cssSelector ? document.querySelectorAll(cssSelector).length : 0; window.persoo("send", "impression", {searchType: "originalSearchResults", query: searchQuery, table: "products", foundResultsCount: searchResultsCount}); } }); }, 10); }); }  mountOriginalSearchImpression('searchtext', '.serp-item');

    /* report default pageview */
    if (!persoo.ignoreDefaultSendPageview && true) {
        persoo('send','pageview');
    }
    persoo('actionScript', 'loaded', 'actions.js');
}
window.persoo = window.persoo || {};
window.persoo.identificationRequestLifeSpan = 'browser';
window.persoo.requestPreprocessor = function (data) {
    var customPreprocessor = function process(event) {
    if (event.monitoringType == 'Výsledky vyhledávání' 
        || window.location.pathname == '/cs/vysledky-vyhledavani'
        || window.location.pathname == '/cs/vysledky-vyhledavani-persoo') {
    	event.pageType = 'search';    
    } else if (event.monitoringType == '404') {
        event.pageType = 'error';
    } else {
        event.pageType = 'detail';
        event.itemID = window.location.href;
    }
    if (event.language == 'cs-CZ' || window.location.pathname.indexOf('/en/') == -1) {
    	event.lang = 'cs';    
    }
    if (event.language == 'en-US') {
        event.lang = 'en';
    }

    if (event.query) {
        event.query = event.query.replace(/\_|-|\/|\.|,|&|\%|\#|>|</g," ");
    } 

    var s = window.location.href.match(/kb\.cz\/(?:cs\/|en\/)*(.+?)(\/|$)/i);
    if (s && s[1] && s[1].match(/podnikatele-a-male-firmy|obcane|firmy-a-instituce/i)) {
        event.segment = s[1];
    }

    event.itemID = window.location.href.replace(/[&?](aspxerrorpath|type|view|lat|lng|display|utm_id|utm_medium|utm_source|utm_term|utm__source|utm_campaign|utm_value)=[^&]+|[&?](os|searchvalue|zoom|center)=[^&]+|[&?]_locale=[^&]+|[&?]ftp=[^&]+|[&?]amount=[^&]+|[&?]instalments=[^&]+|[&?]cf=[^&]+|[&?]s=[^&]+/gi, '');

    return event;
}
;
    var identificationPreprocessor =  function (data, idTypes) { var containsIdentification = data.idType && data.idValue; for (var i = 0; i < idTypes.length && !containsIdentification; i++) { if (data[idTypes[i]]) { data.idType = idTypes[i]; data.idValue = data[idTypes[i]]; delete data[idTypes[i]]; containsIdentification = true; } } return data; } ;
    var unsubscribeLinkPreprocessor =  function (d, idTypes) { var pue = "persooUnsubscribeEmail", pk = "persooKey", r = "Reported"; if (d[pue] && !window.persoo[pue + r]) { window.persoo[pue + r] = 1; var e = d[pue], k = d[pk]; if (k && e == atob(k)) { setTimeout(function () { window.persoo("send", "unsubscribeEmail", {email: e, emailValue: e, key: k}); }, 100); } } delete d[pue]; delete d[pk]; return d; } ;
    var addUrlParamsToData =  function (data, urlParamsMap) { function parseParams(query) { var query_string = {}; var vars = query.split("&"); for (var i = 0; i < vars.length; i++) { var pair = vars[i].split("="); var varName = pair[0]; varVal = pair.splice(1).join("="); if (typeof query_string[varName] === "undefined") { query_string[varName] = varVal; } else { if (typeof query_string[varName] === "string") { var arr = [query_string[varName], varVal]; query_string[varName] = arr; } else { query_string[varName].push(varVal); } } } return query_string; } var search = window.location.search.substring(1); var hash = window.location.hash.substring(1); var queryParams = parseParams(search); var hashParams = parseParams(hash); for (var param in urlParamsMap) { if (urlParamsMap.hasOwnProperty(param)) { var newParam = urlParamsMap[param]; if (typeof queryParams[param] !== "undefined") { data[newParam] = queryParams[param]; } else { if (typeof hashParams[param] !== "undefined") { data[newParam] = hashParams[param]; } } } } return data; } ;
    var idTypes = ["email","userId"];
    var urlParamsMap = {"persooUnsubscribeEmail":"persooUnsubscribeEmail","persooKey":"persooKey"};
    var normalizeQuery =  function (query) { if (Array.isArray(query)) { return query[0]; } else { var queryAsString = (typeof query == "string") ? query : JSON.stringify(query); return queryAsString.toLowerCase().replace(/^\s+|\s+$/g, "").replace(/\s+/g, " "); } } ;
    var eventNameWhitelist = ["pageview","click","impression","submit","close","statistics","addToCart","addToBasket","removeItem","getScenario","getRecommendation","getAlgorithm","suggest","oneSignal","oneSignalWebhook","unsubscribeEmail","updateProfile"];
    var eventNameBlacklist = ["optimize.domChange"];
    
    data = customPreprocessor(data);
    if (data) {
        if (data.query) {data.query = normalizeQuery(data.query);};
        data = addUrlParamsToData(data, urlParamsMap);
        data = unsubscribeLinkPreprocessor(data, idTypes);
        data = identificationPreprocessor(data, idTypes);
        if (eventNameWhitelist.length > 0) {
            if (eventNameWhitelist.indexOf(data._e) < 0) {
                return null;
            }
        } else if (eventNameBlacklist.length > 0 && eventNameBlacklist.indexOf(data._e) >= 0) {
                return null;
        }
    }
    return data;
};
if (!persoo.actionsJSLoaded) {
    persooAddActions(document, window, window.persoo);
}
