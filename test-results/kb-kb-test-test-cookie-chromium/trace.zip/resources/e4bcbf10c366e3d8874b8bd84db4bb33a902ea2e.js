com_sas_ci_acs.ob_boot = {
    getDatahubId:function(){
    return com_sas_ci_acs.ob_util.ckR('_SI_DID_1.01ff93586100011138b31035');
	},
    setDatahubId:function(datahubid){
		com_sas_ci_acs.ob_util_async.ckW('_SI_DID_1.01ff93586100011138b31035',datahubid,'/','.kb.cz,.www.kb.cz',1773364795146);
	}
};
(function(doc, script) {
    var js, 
        fjs = doc.getElementsByTagName(script)[0],
        add = function(url, id) {
            if (doc.getElementById(id)) {return;}
            js = doc.createElement(script);
            js.async = 1;
            js.src = url;
            id && (js.id = id);
            fjs.parentNode.insertBefore(js, fjs);
        }
if(typeof(com_sas_ci_acs.version)==="undefined" || com_sas_ci_acs.version.split('.')[0] < 1){
    com_sas_ci_acs.ob_util.ckW('_SI_VID_1.01ff93586100011138b31035','4c22ebffd4cfb33e6d3115b7','/','.kb.cz,.www.kb.cz',1773364795145);
}
else{
    com_sas_ci_acs.ob_util_async.ckW('_SI_VID_1.01ff93586100011138b31035','4c22ebffd4cfb33e6d3115b7','/','.kb.cz,.www.kb.cz',1773364795145);
}
if(typeof(com_sas_ci_acs.version)==="undefined" || com_sas_ci_acs.version.split('.')[0] < 1){
    com_sas_ci_acs.ob_util.ckW('_SI_DID_1.01ff93586100011138b31035','a5d24558-04d1-3da4-b2ec-20332994fc40','/','.kb.cz,.www.kb.cz');
}
else{
    com_sas_ci_acs.ob_util_async.ckW('_SI_DID_1.01ff93586100011138b31035','a5d24558-04d1-3da4-b2ec-20332994fc40','/','.kb.cz,.www.kb.cz');
}
    if(typeof(com_sas_ci_acs.version)==="undefined" || com_sas_ci_acs.version.split('.')[0] < 1){
        com_sas_ci_acs.ob_util.newvid = true;
    }
    else{
        com_sas_ci_acs.newvid = true;
    }
    com_sas_ci_acs.ob_util_async.load_guid = '8c78f3e1ce3ecf222797d668';
if(typeof(com_sas_ci_acs.version)==="undefined" || com_sas_ci_acs.version.split('.')[0] < 1){
    com_sas_ci_acs.ob_util.sckW('_SI_SID_1.01ff93586100011138b31035','524b56afeb60925110b1d2a6','/','.kb.cz,.www.kb.cz',new Date().getTime(),0);
}
else{
    com_sas_ci_acs.ob_util_async.sckW('_SI_SID_1.01ff93586100011138b31035','524b56afeb60925110b1d2a6','/','.kb.cz,.www.kb.cz',new Date().getTime(),0);
}


}(document, 'script'));
com_sas_ci_acs._ob_configure.prototype.ob_cfg = function()
{
   this.ccs='https://ingest-euw.ci360.sas.com/t/e/01ff93586100011138b31035';
   this.csu='https://delivery360.kbinfo.cz/hserver';
   this.maxContentChange=10;
   this.maxJsVarChange=10;
this.maxMediaEvents=200;this.maxTotalEvents=2000;   this.batchSpots=true;
   this.timeout=2000;
   this.maxCCMatches=10;
   this.customerSpotDelivery=false;
   this.virtualSpotClassId='';
   if(typeof(com_sas_ci_acs.version)==="undefined" || com_sas_ci_acs.version.split('.')[0] < 1){
      this.load_guid = '8c78f3e1ce3ecf222797d668';
   }
   else{
      this.load_guid = com_sas_ci_acs.ob_util_async.load_guid;
   }
   this.thousands_separator=' ';
   this.decimal_separator=',';
   if(typeof(com_sas_ci_acs.ob_util.setBaseTimestamp)!=="undefined"){
      com_sas_ci_acs.ob_util.setBaseTimestamp(1710292795146);
   }
   this.sendBodyAsHeaderAll=false;
   this.sendBodyAsHeaderLoad=false;
   this.trackCancelledEvents=false;
   this.trackEventResponses=false;
}
com_sas_ci_acs._ob_configure.prototype.getVisitorId = function()
{
    return com_sas_ci_acs.ob_util.ckR('_SI_VID_1.01ff93586100011138b31035');
}
com_sas_ci_acs._ob_configure.prototype.getDatahubId = function()
{
     return com_sas_ci_acs.ob_boot.getDatahubId();
}
com_sas_ci_acs._ob_configure.prototype.getSessionId = function()
{
    var v=com_sas_ci_acs.ob_util.ckR('_SI_SID_1.01ff93586100011138b31035');
    if (v==null) return '';
    return v.split('.')[0];
}
com_sas_ci_acs._ob_configure.prototype.getLastActivity = function()
{
    var v=com_sas_ci_acs.ob_util.ckR('_SI_SID_1.01ff93586100011138b31035');
    if (v==null) return 0;
    var a=v.split('.');
    if (a.length < 2) return 0;
    return a[1];
}
com_sas_ci_acs._ob_configure.prototype.getMaxInactivity = function()
{
    var v=com_sas_ci_acs.ob_util.ckR('_SI_SID_1.01ff93586100011138b31035');
    if (v==null) return 0;
    var a=v.split('.');
    if (a.length < 3) return 0;
    return a[2];
}
com_sas_ci_acs._ob_configure.prototype.updateActivity = function(ts1, ts2)
{
 var latestSid=this.getSessionId(); latestSid = latestSid?latestSid:'524b56afeb60925110b1d2a6';    com_sas_ci_acs.ob_util.sckW('_SI_SID_1.01ff93586100011138b31035', latestSid , '/','.kb.cz,.www.kb.cz', ts1, ts2);
}
com_sas_ci_acs.ob_event.prototype.termConfiguration = function()
{
    var terms = {};

    terms['global'] = {};
    terms['find'] = {};
    terms['load'] = {};
    terms['tsp'] = {};
    terms['DOMContentLoaded'] = {};
    terms['click'] = {};
    terms['exclude'] = {};
    terms['blur'] = {};
    terms['change'] = {};
    terms['cart'] = {};
    terms['submit'] = {};

if(!com_sas_ci_acs.csz){com_sas_ci_acs.csz=document.documentElement.outerHTML.length;}if(!com_sas_ci_acs.bsz){com_sas_ci_acs.bsz=window.innerWidth+'x'+window.innerHeight;}terms['global']['page_title'] = document.title;
terms['global']['referrer'] = document.referrer;
terms['global']['uri'] = document.URL;
terms['global']['requestedfile'] = com_sas_ci_acs.ob_util.parseUri(document.URL).path;
terms['load']['tzo'] = new Date().getTimezoneOffset();
terms['load']['platform'] = navigator.platform;
terms['load']['cpu'] = navigator.cpuClass;
terms['load']['port'] = location.port;
terms['load']['protocol'] = com_sas_ci_acs.ob_util.location();
terms['load']['flash_enabled'] = com_sas_ci_acs.ob_util.flash().e;
terms['load']['flash_version'] = com_sas_ci_acs.ob_util.flash().v;
terms['load']['javascript_enabled'] = true;
terms['load']['java_enabled'] = com_sas_ci_acs.ob_util.java().e;
terms['load']['java_version'] = com_sas_ci_acs.ob_util.java().v;
terms['load']['screen_info'] = screen.width + 'x' + screen.height + '@' + screen.colorDepth;
if (!com_sas_ci_acs.ob_util.isUndefined(document.documentElement)&&(null!=document.documentElement.getAttribute('lang'))) terms['load']['html.lang'] = document.documentElement.getAttribute('lang');
if (!com_sas_ci_acs.ob_util.isUndefined(document.documentElement)&&(null!=document.documentElement.getAttribute('xml:lang'))) terms['load']['html.xml:lang'] = document.documentElement.getAttribute('xml:lang');
terms['load']['browser_language'] = !com_sas_ci_acs.ob_util.isUndefined(navigator.language) ? navigator.language : navigator.browserLanguage;
terms['load']['character_set'] = com_sas_ci_acs.ob_util.isUndefined(document.charset)?document.characterSet:document.charset;
terms['load']['csz'] = com_sas_ci_acs.csz;
terms['load']['bsz'] = com_sas_ci_acs.bsz;
terms['DOMContentLoaded']['tzo'] = new Date().getTimezoneOffset();
terms['DOMContentLoaded']['platform'] = navigator.platform;
terms['DOMContentLoaded']['cpu'] = navigator.cpuClass;
terms['DOMContentLoaded']['port'] = location.port;
terms['DOMContentLoaded']['protocol'] = com_sas_ci_acs.ob_util.location();
terms['DOMContentLoaded']['flash_enabled'] = com_sas_ci_acs.ob_util.flash().e;
terms['DOMContentLoaded']['flash_version'] = com_sas_ci_acs.ob_util.flash().v;
terms['DOMContentLoaded']['javascript_enabled'] = true;
terms['DOMContentLoaded']['java_enabled'] = com_sas_ci_acs.ob_util.java().e;
terms['DOMContentLoaded']['java_version'] = com_sas_ci_acs.ob_util.java().v;
terms['DOMContentLoaded']['screen_info'] = screen.width + 'x' + screen.height + '@' + screen.colorDepth;
if (!com_sas_ci_acs.ob_util.isUndefined(document.documentElement)&&(null!=document.documentElement.getAttribute('lang'))) terms['DOMContentLoaded']['html.lang'] = document.documentElement.getAttribute('lang');
if (!com_sas_ci_acs.ob_util.isUndefined(document.documentElement)&&(null!=document.documentElement.getAttribute('xml:lang'))) terms['DOMContentLoaded']['html.xml:lang'] = document.documentElement.getAttribute('xml:lang');
terms['DOMContentLoaded']['browser_language'] = !com_sas_ci_acs.ob_util.isUndefined(navigator.language) ? navigator.language : navigator.browserLanguage;
terms['DOMContentLoaded']['character_set'] = com_sas_ci_acs.ob_util.isUndefined(document.charset)?document.characterSet:document.charset;
terms['DOMContentLoaded']['csz'] = com_sas_ci_acs.csz;
terms['DOMContentLoaded']['bsz'] = com_sas_ci_acs.bsz;

terms['tsp']['pe_64ade5d8db834fe912fc968c304b7999'] = '#kbonline-target > kbonline-target > app-root > app-main > div > form > app-wizard > div > div > div > div > div > app-footer > div.row.ng2-f-wizard-footer > button';
terms['tsp']['pe_23fc73777bb7eeb4ae7cf420c1eb09d8'] = '#calculator-loan > div > div > div > div.hidden-print > div > div.d-flex.w-100 > div > div.text-center.mt-5.mt-lg-5 > button > div';
terms['tsp']['pe_575abba10ffc2e32f80dd6fb33c142e6'] = '#calculator-loan > div > div > div.hidden-print > div.hidden-print > div > div.flipper-static.flex-lg-nowrap.d-lg-flex.my-lg-3.w-100 > div > div.flipper-static__front.w-100.d-flex > div > div.text-center.mt-auto > button > span';

    return terms;
}
com_sas_ci_acs._ob_cart_configuration.prototype.getCartConfig = function()
{
   var cart = {};



    return cart;
}
com_sas_ci_acs._ob_cart_configuration.prototype.getCheckoutConfig = function()
{
   var cart = {};



    return cart;
}
com_sas_ci_acs._ob_cart_configuration.prototype.getPurchaseConfig = function()
{
   var cart = {};



    return cart;
}
com_sas_ci_acs._ob_jsvar_configuration.prototype.getConfig = function()
{
    var jsVars = {};


jsVars['page_id'] = '';

    return jsVars;
}
com_sas_ci_acs._ob_jsvarchange_configuration.prototype.getConfig = function()
{
    var jsChangeVars = {};


    return jsChangeVars;
}
com_sas_ci_acs._ob_contentvisible_configuration.prototype.getConfig = function()
{
    var contentVars = {};



    return contentVars;
}
com_sas_ci_acs._ob_configure.prototype.getFormConfig = function()
{
   var ff = {};
   ff['nature'] = 'inc';

   ff['obs'] = [];
   ff['ign'] = [];
   ff['inc'] = [];


ff['nature'] = 'ign';

    return ff;
}
com_sas_ci_acs._ob_configure.prototype.isCollectionEnabled = function()
{
   var collect = {};


collect['clicks'] = 'true';
collect['contentevents'] = 'false';
collect['fieldinteractions'] = 'false';
collect['formsubmits'] = 'true';
collect['jsvars'] = 'true';
collect['media'] = 'true';
collect['mouseovers'] = 'false';
collect['pageloads'] = 'true';

   collect['pageloads_eventid'] = [];
   collect['pageloads_eventname'] = [];
   collect['pageloads_eventtype'] = [];
   collect['pageloads_eventsubtype'] = [];
   collect['pageloads_prd_selector'] = [];
   collect['pageloads_system_type'] = [];
   collect['formsubmits_eventid'] = [];
   collect['formsubmits_eventname'] = [];
   collect['formsubmits_system_type'] = [];
   collect['formsubmits_elements'] = [];
   collect['clicks_eventid'] = [];
   collect['clicks_eventname'] = [];
   collect['clicks_system_type'] = [];
   collect['changevar_eventid'] = [];
   collect['changevar_attributes'] = [];
   collect['content_eventid'] = [];
   collect['content_attributes'] = [];
   collect['pageloads_attributes'] = [];
   collect['formsubmits_attributes'] = [];
   collect['clicks_attributes'] = [];
   collect['event_properties'] = [];
   collect['clickThrough_system_eventid'] = [];
   collect['impression_system_eventid'] = [];
   collect['pageloads_system_eventid'] = [];
   collect['newsession_system_eventid'] = [];
   collect['focus_system_eventid'] = [];
   collect['defocus_system_eventid'] = [];
   collect['notification_opened_system_eventid'] = [];
   collect['email_open_system_eventid'] = [];
   collect['email_send_system_eventid'] = [];
   collect['email_view_system_eventid'] = [];
   collect['email_click_system_eventid'] = [];
   collect['email_hard_bounce_system_eventid'] = [];
   collect['email_opt-out_system_eventid'] = [];
   collect['email_spam_system_eventid'] = [];
   collect['email_reply_system_eventid'] = [];
   collect['loginevent_attributes'] = [];

collect['impression_system_eventid'].push('0327edc0-953a-4521-ade8-d26f79fdc7fc');

collect['email_reply_system_eventid'].push('349d154f-b055-4544-808a-38084b80607c');

collect['pageloads_system_eventid'].push('4b873d55-1f2d-4d76-bc2d-89bb63ac7bc0');

collect['email_view_system_eventid'].push('4d70d5c4-b093-472a-8819-2003c77dcfba');

collect['email_open_system_eventid'].push('5f4c10d5-2e33-48f9-a653-cc88f1fdb0f7');

collect['email_hard_bounce_system_eventid'].push('9fdf7408-f628-420c-b6db-2cf0cd35ffaa');

collect['email_opt-out_system_eventid'].push('afb0d633-206a-4e07-b317-f9f4b1ab744b');

collect['newsession_system_eventid'].push('bb866071-42ae-485f-b35e-ec39e5c0a120');

collect['notification_opened_system_eventid'].push('bf931fca-4a26-4542-9f28-9013df9a45e5');

collect['email_click_system_eventid'].push('cdf2670a-2fbc-4db3-91cc-cb275ce902ac');

collect['email_send_system_eventid'].push('d18bba06-561a-4272-8ad8-8db3c6b70613');

collect['email_spam_system_eventid'].push('d2df32c8-846e-422d-a0b8-d32dd92308e9');

collect['clickThrough_system_eventid'].push('f62d126b-b384-450a-8c7a-c122c5e6b738');

collect['pageloads_eventid'].push('fe2682f6-8b39-40f0-9bcc-131f62d40199');
collect['pageloads_eventname']['fe2682f6-8b39-40f0-9bcc-131f62d40199'] = 'CAAS';
collect['pageloads_eventtype']['fe2682f6-8b39-40f0-9bcc-131f62d40199'] = 'pageView';
collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'] = [];
collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'][0]=[];collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'][0]['name']='User_ID_Attribute';collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'][0]['cart_att_type']='OTHER';collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'][0]['cookie']='oid';collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'][0]['attribute']='';collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'][0]['type']='string';collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'][0]['filter']='none';collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'][0]['filterpattern']='';collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'][0]['login_event_type'] = 'login_id';
collect['loginevent_attributes']['fe2682f6-8b39-40f0-9bcc-131f62d40199'][0]['obscured'] = 'false';


    return collect;
}

com_sas_ci_acs.ob_util.specialClickProcessing=true;
com_sas_ci_acs.cacheCollect=com_sas_ci_acs._ob_configure.prototype.isCollectionEnabled();com_sas_ci_acs._ob_configure.prototype.isCollectionEnabled=function(){return com_sas_ci_acs.cacheCollect;};
com_sas_ci_acs.ob_configure.initialize();
