(function() {
function loadScript(uri) {
const timeoutTime = 12000;
const script = document.createElement('script');
script.setAttribute('charset', 'UTF-8');
script.setAttribute('type', 'text/javascript');
script.setAttribute('async', true);
script.setAttribute('timeout', timeoutTime);
script.src = uri;
const timeoutHandle = setTimeout(function() {onError('Timeout');}, timeoutTime);
script.onerror = onError;
function onComplete() {
    // avoid mem leaks in IE.    script.onerror = script.onload = null;
    clearTimeout(timeoutHandle);
}
function onError(result) {
    onComplete();
    console.error('Failed to load script! Uri:', uri, 'Result:', result);
}
script.onload = function () {
    onComplete();
};
const head = document.getElementsByTagName('HEAD')[0];
head.appendChild(script);
}
if(window.unblu && window.unblu.APIKEY) {console.warn('Existing unblu detected while loading unblu. Please check site for double injection!'); return;}
if (!window['x-unblu-tmp-window-name']) window['x-unblu-tmp-window-name']=window.name;
window.unblu = window.unblu || {};
window.unblu.APIKEY = 'rAd9B3aESWWmJ9MAllcbOQ';
window.unblu.entryPoint = 'SiteIntegrationLazyMain';
window.unblu.bi = '_unblu_572F594F_21AA_4D30_8081_40F2793592AF';

function extractServerUrl(prefix) {
	var VISITOR_JS_PART = prefix + '/visitor.js';
	var script = document.querySelector('script[src*="' + VISITOR_JS_PART + '"]');
	if (!script) {
		console.warn('Could not find unblu script tag. Assuming relative path.');
       return '';
	}
	var regex = new RegExp('(.*)' + VISITOR_JS_PART.replace('/', '\/').replace('.', '\.'));
	var match = regex.exec(script.src);
	if (match == null || match.length < 1)
		console.error('Error loading unblu, can\'t extract unblu server from visitor.js script tag');
	else
		return match[1];
}
if(!window.unblu.SERVER) window.unblu.SERVER = extractServerUrl('/unblu');
window['_unblu_572F594F_21AA_4D30_8081_40F2793592AF'] = {"$_cfg":{"g7":"","isDeploymentModeProduction":true,"bi":"_unblu_572F594F_21AA_4D30_8081_40F2793592AF","O9":"x-unblu-kb","ALt":false,"Dct":"","cft":true,"_ft":false,"multiAccount":true,"uft":false,"f7":null,"Qp":12000,"Np":1708112847630,"Gp":1710292189648,"agentAvailabilityVersion":1710277189000,"qp":null,"Zp":"en-US","Kp":null,"Jp":null,"xm":"","defaultOriginPublic":"","N4e":"RWp_4X0lS8SV94vXrVWrZQ"}};
window['_unblu_572F594F_21AA_4D30_8081_40F2793592AF']['$_cfg']['m7'] = window['x-unblu-tmp-systempath'] || '/unblu';
window['_unblu_572F594F_21AA_4D30_8081_40F2793592AF']['$_cfg']['systemPathPrefix'] = window['x-unblu-tmp-systempath-prefix'] || '/unblu';
window['_unblu_572F594F_21AA_4D30_8081_40F2793592AF']['$_cfg']['b7'] = window['x-unblu-tmp-systempath-public'] || '/unblu';
loadScript(window.unblu.SERVER + '/unblu' + '/static/js/wp/xmd1708112847630/Initializer.js');
})();