(function () {
        class MicroFrontendAngularApp extends HTMLElement {
  // Following "constants" will be overwritten in the descendent class
  PLATFORM_BROWSER_VAR_NAME = null;
  BOOTSTRAP_VAR_NAME = null;
  ANGULAR_PREFIX = null;
  ZONE_URL = null;

  APP_MANIFEST_GLOBAL_VAR_NAME = null;

  path = null;
  inputData = null;
  uniqId = null;

  static get observedAttributes() {
    return ['data-path', 'data-input'];
  }

  constructor() {
    super();

    this.PLATFORM_BROWSER_VAR_NAME = '';
    this.BOOTSTRAP_VAR_NAME = '';
    this.ANGULAR_PREFIX = 'app';
    this.ZONE_URL = 'https://cdn.jsdelivr.net/npm/zone.js@0.11.8/dist/zone.min.js';

    this.APP_MANIFEST_GLOBAL_VAR_NAME = '';

    this.path = null;
    this.inputData = null;

    this.uniqId = +new Date();
  }

  connectedCallback() {
    // setup global var name
    this.APP_MANIFEST_GLOBAL_VAR_NAME = `${this.ANGULAR_PREFIX}_manifest`;
    // get dynamically the path from the script name if not received as attribute
    this.path = this.path || new Error().stack.match(/http(s)?:\/\/.*?\//gi)[0];
    // run the app
    this.initApp();
  }

  disconnectedCallback() {
    window[this.PLATFORM_BROWSER_VAR_NAME + this.uniqId]().destroy();
  }

  attributeChangedCallback(attr, oldValue, newValue) {
    switch (attr) {
      case 'data-input':
        this.inputData = JSON.parse(newValue);
        break;
      case 'data-path':
        this.path = newValue;
        break;
    }
  }

  initApp() {
    // check if files has been already loaded
    if (!window[this.APP_MANIFEST_GLOBAL_VAR_NAME]) {
      fetch(`${this.path}manifest.json`)
        .then(
          (response) => response.json(),
          (err) => {
            this._dispatchLoadFailedEvent(err);
          }
        )
        .then((manifest) => {
          if (manifest?.runtime) {
            // load app files
            this._loadAppFiles(manifest).then(() => {
              this.setAttribute('loaded', true);
              this._bootstrapApp();
            });
          }
        });
    } else {
      // if the app was already once loaded, bootstrap the app again (scripts are saved in memory and styles stayed in the head)
      this.setAttribute('loaded', true);
      this._bootstrapApp();
    }
  }

  _bootstrapApp() {
    try {
      // add the element where the angular app is going to be rendered
      this.appendChild(document.createElement(`${this.ANGULAR_PREFIX}-root`));
      // bootstrap Angular app
      window[this.BOOTSTRAP_VAR_NAME](this.uniqId, this.inputData);
    } catch (err) {
      this._dispatchLoadFailedEvent(err);
    }
  }

  _loadAppFiles(manifest) {
    // load scripts and styles
    return Promise.all([
      this._insertZone(),
      this._loadScript(`${this.path}${manifest.runtime}`, true, 'module'),
      this._loadScript(`${this.path}${manifest.polyfills}`, true, 'module'),
      this._loadScript(`${this.path}${manifest.main}`, true, 'module'),
      this._loadStyle(`${this.path}${manifest.styles}`),
    ]).then(
      () => {
        window[this.APP_MANIFEST_GLOBAL_VAR_NAME] = manifest; // tag as loaded
      },
      (err) => {
        this._dispatchLoadFailedEvent(err);
      }
    );
  }

  _loadScript(FILE_URL, async = true, type = 'text/javascript') {
    return new Promise((resolve, reject) => {
      try {
        const scriptEle = document.createElement('script');
        scriptEle.type = type;
        scriptEle.async = async;
        scriptEle.src = FILE_URL;

        scriptEle.addEventListener('load', (ev) => {
          resolve({ status: true });
        });

        scriptEle.addEventListener('error', (ev) => {
          reject({
            status: false,
            message: `Failed to load the script ${FILE_URL}`,
          });
        });

        this.appendChild(scriptEle);
      } catch (error) {
        reject(error);
      }
    });
  }

  _loadStyle(FILE_URL, rel = 'stylesheet') {
    return new Promise((resolve, reject) => {
      try {
        const head = document.querySelector('head');
        const styleEle = document.createElement('link');

        styleEle.rel = rel;
        styleEle.href = FILE_URL;

        styleEle.addEventListener('load', (ev) => {
          resolve({ status: true });
        });

        styleEle.addEventListener('error', (ev) => {
          reject({
            status: false,
            message: `Failed to load the styles ${FILE_URL}`,
          });
        });

        head.appendChild(styleEle);
      } catch (error) {
        reject(error);
      }
    });
  }

  // only one zone file can be on the side with multiple Angular apps
  _insertZone() {
    // set zoneUrl based on whatever or not is the ZONE_URL absolute path or relative
    const zoneUrl = /http(s)?:\/\//.test(this.ZONE_URL) ? this.ZONE_URL : `${this.path}${this.ZONE_URL.replace(/^[\/]?/, '')}`;

    const zone = document.querySelector('script[src$="zone.min.js"]');

    return new Promise((resolve, reject) => {
      try {
        if (!zone) {
          const newZone = document.createElement('script');
          newZone.src = zoneUrl;
          newZone.async = true;

          MicroFrontendAngularApp._setZoneListeners(newZone, resolve, reject);

          document.body.appendChild(newZone);
        } else if (!zone.hasAttribute('loaded')) {
          MicroFrontendAngularApp._setZoneListeners(zone, resolve, reject);
        } else {
          resolve({ status: null });
        }
      } catch (err) {
        reject(err);
      }
    });
  }

  _dispatchLoadFailedEvent(err) {
    console.error(err);
    document.dispatchEvent(new CustomEvent(`${this.ANGULAR_PREFIX}:load-failed`));
  }

  static _setZoneListeners(zoneEl, resolve, reject) {
    zoneEl.addEventListener('load', (ev) => {
      zoneEl.setAttribute('loaded', true);
      resolve({ status: true });
    });

    zoneEl.addEventListener('error', (ev) => {
      reject({
        status: false,
        message: `Failed to load the script Zone.js`,
      });
    });
  }
}
!function(){class s extends MicroFrontendAngularApp{ANGULAR_PREFIX="kbo";PLATFORM_BROWSER_VAR_NAME="platformBrowserKboApp";BOOTSTRAP_VAR_NAME="bootstrapKboApp";ZONE_URL="/kbo-assets/scripts/zone.min.js"}window.customElements.define("kbo-app",s);let o=!1,d="kbo-app";document.addEventListener("kbo:load",t=>{if(o)return;if(o=!0,!document.querySelector(d)){let a=t.detail?.path||null;if(!a){const i=document.querySelector('script[src$="kbo.js"]');if(i){const r=i.getAttribute("src");a=/^(.*)kbo\.js$/.exec(r)[1]}}const e=document.createElement(d);return t.detail?.id&&e.setAttribute("id",t.detail.id),e.setAttribute("data-path",a||"/"),e.setAttribute("data-input",JSON.stringify(t.detail||{})),e.style.zIndex="2000000000",void document.body.appendChild(e)}let n=document.querySelector(d);if(!n.hasAttribute("loaded"))return n.remove(),void document.body.appendChild(n);document.dispatchEvent(new CustomEvent("kbo:loaded")),t.detail?.useCase&&document.dispatchEvent(new CustomEvent("kbo:run",{detail:t.detail}))}),document.addEventListener("kbo:loaded",()=>{o=!1}),document.addEventListener("kbo:load-failed",()=>{o=!1})}();
      })();