'use strict';
var __spreadArray =
  (this && this.__spreadArray) ||
  function (e, t, n) {
    if (n || 2 === arguments.length) for (var r, o = 0, a = t.length; o < a; o++) (!r && o in t) || (r || (r = Array.prototype.slice.call(t, 0, o)), (r[o] = t[o]));
    return e.concat(r || Array.prototype.slice.call(t));
  };
/**
 * @license Angular v14.2.0-next.0
 * (c) 2010-2022 Google LLC. https://angular.io/
 * License: MIT
 */ !(function (e) {
  'function' == typeof define && define.amd ? define(e) : e();
})(function () {
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */
  !(function (e) {
    var t = e.performance;
    function n(e) {
      t && t.mark && t.mark(e);
    }
    function r(e, n) {
      t && t.measure && t.measure(e, n);
    }
    n('Zone');
    var o = e.__Zone_symbol_prefix || '__zone_symbol__';
    function a(e) {
      return o + e;
    }
    var i = !0 === e[a('forceDuplicateZoneCheck')];
    if (e.Zone) {
      if (i || 'function' != typeof e.Zone.__symbol__) throw new Error('Zone already loaded.');
      return e.Zone;
    }
    var c = (function () {
      function t(e, t) {
        (this._parent = e), (this._name = t ? t.name || 'unnamed' : '<root>'), (this._properties = (t && t.properties) || {}), (this._zoneDelegate = new l(this, this._parent && this._parent._zoneDelegate, t));
      }
      return (
        (t.assertZonePatched = function () {
          if (e.Promise !== j.ZoneAwarePromise)
            throw new Error(
              'Zone.js has detected that ZoneAwarePromise `(window|global).Promise` has been overwritten.\nMost likely cause is that a Promise polyfill has been loaded after Zone.js (Polyfilling Promise api is not necessary when zone.js is loaded. If you must load one, do so before loading zone.js.)'
            );
        }),
        Object.defineProperty(t, 'root', {
          get: function () {
            for (var e = t.current; e.parent; ) e = e.parent;
            return e;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(t, 'current', {
          get: function () {
            return z.zone;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(t, 'currentTask', {
          get: function () {
            return M;
          },
          enumerable: !1,
          configurable: !0,
        }),
        (t.__load_patch = function (o, a, c) {
          if ((void 0 === c && (c = !1), j.hasOwnProperty(o))) {
            if (!c && i) throw Error('Already loaded patch: ' + o);
          } else if (!e['__Zone_disable_' + o]) {
            var s = 'Zone:' + o;
            n(s), (j[o] = a(e, t, C)), r(s, s);
          }
        }),
        Object.defineProperty(t.prototype, 'parent', {
          get: function () {
            return this._parent;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(t.prototype, 'name', {
          get: function () {
            return this._name;
          },
          enumerable: !1,
          configurable: !0,
        }),
        (t.prototype.get = function (e) {
          var t = this.getZoneWith(e);
          if (t) return t._properties[e];
        }),
        (t.prototype.getZoneWith = function (e) {
          for (var t = this; t; ) {
            if (t._properties.hasOwnProperty(e)) return t;
            t = t._parent;
          }
          return null;
        }),
        (t.prototype.fork = function (e) {
          if (!e) throw new Error('ZoneSpec required!');
          return this._zoneDelegate.fork(this, e);
        }),
        (t.prototype.wrap = function (e, t) {
          if ('function' != typeof e) throw new Error('Expecting function got: ' + e);
          var n = this._zoneDelegate.intercept(this, e, t),
            r = this;
          return function () {
            return r.runGuarded(n, this, arguments, t);
          };
        }),
        (t.prototype.run = function (e, t, n, r) {
          z = { parent: z, zone: this };
          try {
            return this._zoneDelegate.invoke(this, e, t, n, r);
          } finally {
            z = z.parent;
          }
        }),
        (t.prototype.runGuarded = function (e, t, n, r) {
          void 0 === t && (t = null), (z = { parent: z, zone: this });
          try {
            try {
              return this._zoneDelegate.invoke(this, e, t, n, r);
            } catch (e) {
              if (this._zoneDelegate.handleError(this, e)) throw e;
            }
          } finally {
            z = z.parent;
          }
        }),
        (t.prototype.runTask = function (e, t, n) {
          if (e.zone != this) throw new Error('A task can only be run in the zone of creation! (Creation: ' + (e.zone || k).name + '; Execution: ' + this.name + ')');
          if (e.state !== b || (e.type !== D && e.type !== Z)) {
            var r = e.state != w;
            r && e._transitionTo(w, E), e.runCount++;
            var o = M;
            (M = e), (z = { parent: z, zone: this });
            try {
              e.type == Z && e.data && !e.data.isPeriodic && (e.cancelFn = void 0);
              try {
                return this._zoneDelegate.invokeTask(this, e, t, n);
              } catch (e) {
                if (this._zoneDelegate.handleError(this, e)) throw e;
              }
            } finally {
              e.state !== b && e.state !== S && (e.type == D || (e.data && e.data.isPeriodic) ? r && e._transitionTo(E, w) : ((e.runCount = 0), this._updateTaskCount(e, -1), r && e._transitionTo(b, w, b))),
                (z = z.parent),
                (M = o);
            }
          }
        }),
        (t.prototype.scheduleTask = function (e) {
          if (e.zone && e.zone !== this)
            for (var t = this; t; ) {
              if (t === e.zone) throw Error('can not reschedule task to '.concat(this.name, ' which is descendants of the original zone ').concat(e.zone.name));
              t = t.parent;
            }
          e._transitionTo(T, b);
          var n = [];
          (e._zoneDelegates = n), (e._zone = this);
          try {
            e = this._zoneDelegate.scheduleTask(this, e);
          } catch (t) {
            throw (e._transitionTo(S, T, b), this._zoneDelegate.handleError(this, t), t);
          }
          return e._zoneDelegates === n && this._updateTaskCount(e, 1), e.state == T && e._transitionTo(E, T), e;
        }),
        (t.prototype.scheduleMicroTask = function (e, t, n, r) {
          return this.scheduleTask(new f(P, e, t, n, r, void 0));
        }),
        (t.prototype.scheduleMacroTask = function (e, t, n, r, o) {
          return this.scheduleTask(new f(Z, e, t, n, r, o));
        }),
        (t.prototype.scheduleEventTask = function (e, t, n, r, o) {
          return this.scheduleTask(new f(D, e, t, n, r, o));
        }),
        (t.prototype.cancelTask = function (e) {
          if (e.zone != this) throw new Error('A task can only be cancelled in the zone of creation! (Creation: ' + (e.zone || k).name + '; Execution: ' + this.name + ')');
          e._transitionTo(O, E, w);
          try {
            this._zoneDelegate.cancelTask(this, e);
          } catch (t) {
            throw (e._transitionTo(S, O), this._zoneDelegate.handleError(this, t), t);
          }
          return this._updateTaskCount(e, -1), e._transitionTo(b, O), (e.runCount = 0), e;
        }),
        (t.prototype._updateTaskCount = function (e, t) {
          var n = e._zoneDelegates;
          -1 == t && (e._zoneDelegates = null);
          for (var r = 0; r < n.length; r++) n[r]._updateTaskCount(e.type, t);
        }),
        t
      );
    })();
    c.__symbol__ = a;
    var s,
      u = {
        name: '',
        onHasTask: function (e, t, n, r) {
          return e.hasTask(n, r);
        },
        onScheduleTask: function (e, t, n, r) {
          return e.scheduleTask(n, r);
        },
        onInvokeTask: function (e, t, n, r, o, a) {
          return e.invokeTask(n, r, o, a);
        },
        onCancelTask: function (e, t, n, r) {
          return e.cancelTask(n, r);
        },
      },
      l = (function () {
        function e(e, t, n) {
          (this._taskCounts = { microTask: 0, macroTask: 0, eventTask: 0 }),
            (this.zone = e),
            (this._parentDelegate = t),
            (this._forkZS = n && (n && n.onFork ? n : t._forkZS)),
            (this._forkDlgt = n && (n.onFork ? t : t._forkDlgt)),
            (this._forkCurrZone = n && (n.onFork ? this.zone : t._forkCurrZone)),
            (this._interceptZS = n && (n.onIntercept ? n : t._interceptZS)),
            (this._interceptDlgt = n && (n.onIntercept ? t : t._interceptDlgt)),
            (this._interceptCurrZone = n && (n.onIntercept ? this.zone : t._interceptCurrZone)),
            (this._invokeZS = n && (n.onInvoke ? n : t._invokeZS)),
            (this._invokeDlgt = n && (n.onInvoke ? t : t._invokeDlgt)),
            (this._invokeCurrZone = n && (n.onInvoke ? this.zone : t._invokeCurrZone)),
            (this._handleErrorZS = n && (n.onHandleError ? n : t._handleErrorZS)),
            (this._handleErrorDlgt = n && (n.onHandleError ? t : t._handleErrorDlgt)),
            (this._handleErrorCurrZone = n && (n.onHandleError ? this.zone : t._handleErrorCurrZone)),
            (this._scheduleTaskZS = n && (n.onScheduleTask ? n : t._scheduleTaskZS)),
            (this._scheduleTaskDlgt = n && (n.onScheduleTask ? t : t._scheduleTaskDlgt)),
            (this._scheduleTaskCurrZone = n && (n.onScheduleTask ? this.zone : t._scheduleTaskCurrZone)),
            (this._invokeTaskZS = n && (n.onInvokeTask ? n : t._invokeTaskZS)),
            (this._invokeTaskDlgt = n && (n.onInvokeTask ? t : t._invokeTaskDlgt)),
            (this._invokeTaskCurrZone = n && (n.onInvokeTask ? this.zone : t._invokeTaskCurrZone)),
            (this._cancelTaskZS = n && (n.onCancelTask ? n : t._cancelTaskZS)),
            (this._cancelTaskDlgt = n && (n.onCancelTask ? t : t._cancelTaskDlgt)),
            (this._cancelTaskCurrZone = n && (n.onCancelTask ? this.zone : t._cancelTaskCurrZone)),
            (this._hasTaskZS = null),
            (this._hasTaskDlgt = null),
            (this._hasTaskDlgtOwner = null),
            (this._hasTaskCurrZone = null);
          var r = n && n.onHasTask;
          (r || (t && t._hasTaskZS)) &&
            ((this._hasTaskZS = r ? n : u),
            (this._hasTaskDlgt = t),
            (this._hasTaskDlgtOwner = this),
            (this._hasTaskCurrZone = e),
            n.onScheduleTask || ((this._scheduleTaskZS = u), (this._scheduleTaskDlgt = t), (this._scheduleTaskCurrZone = this.zone)),
            n.onInvokeTask || ((this._invokeTaskZS = u), (this._invokeTaskDlgt = t), (this._invokeTaskCurrZone = this.zone)),
            n.onCancelTask || ((this._cancelTaskZS = u), (this._cancelTaskDlgt = t), (this._cancelTaskCurrZone = this.zone)));
        }
        return (
          (e.prototype.fork = function (e, t) {
            return this._forkZS ? this._forkZS.onFork(this._forkDlgt, this.zone, e, t) : new c(e, t);
          }),
          (e.prototype.intercept = function (e, t, n) {
            return this._interceptZS ? this._interceptZS.onIntercept(this._interceptDlgt, this._interceptCurrZone, e, t, n) : t;
          }),
          (e.prototype.invoke = function (e, t, n, r, o) {
            return this._invokeZS ? this._invokeZS.onInvoke(this._invokeDlgt, this._invokeCurrZone, e, t, n, r, o) : t.apply(n, r);
          }),
          (e.prototype.handleError = function (e, t) {
            return !this._handleErrorZS || this._handleErrorZS.onHandleError(this._handleErrorDlgt, this._handleErrorCurrZone, e, t);
          }),
          (e.prototype.scheduleTask = function (e, t) {
            var n = t;
            if (this._scheduleTaskZS)
              this._hasTaskZS && n._zoneDelegates.push(this._hasTaskDlgtOwner), (n = this._scheduleTaskZS.onScheduleTask(this._scheduleTaskDlgt, this._scheduleTaskCurrZone, e, t)) || (n = t);
            else if (t.scheduleFn) t.scheduleFn(t);
            else {
              if (t.type != P) throw new Error('Task is missing scheduleFn.');
              _(t);
            }
            return n;
          }),
          (e.prototype.invokeTask = function (e, t, n, r) {
            return this._invokeTaskZS ? this._invokeTaskZS.onInvokeTask(this._invokeTaskDlgt, this._invokeTaskCurrZone, e, t, n, r) : t.callback.apply(n, r);
          }),
          (e.prototype.cancelTask = function (e, t) {
            var n;
            if (this._cancelTaskZS) n = this._cancelTaskZS.onCancelTask(this._cancelTaskDlgt, this._cancelTaskCurrZone, e, t);
            else {
              if (!t.cancelFn) throw Error('Task is not cancelable');
              n = t.cancelFn(t);
            }
            return n;
          }),
          (e.prototype.hasTask = function (e, t) {
            try {
              this._hasTaskZS && this._hasTaskZS.onHasTask(this._hasTaskDlgt, this._hasTaskCurrZone, e, t);
            } catch (t) {
              this.handleError(e, t);
            }
          }),
          (e.prototype._updateTaskCount = function (e, t) {
            var n = this._taskCounts,
              r = n[e],
              o = (n[e] = r + t);
            if (o < 0) throw new Error('More tasks executed then were scheduled.');
            (0 != r && 0 != o) || this.hasTask(this.zone, { microTask: n.microTask > 0, macroTask: n.macroTask > 0, eventTask: n.eventTask > 0, change: e });
          }),
          e
        );
      })(),
      f = (function () {
        function t(n, r, o, a, i, c) {
          if (
            ((this._zone = null),
            (this.runCount = 0),
            (this._zoneDelegates = null),
            (this._state = 'notScheduled'),
            (this.type = n),
            (this.source = r),
            (this.data = a),
            (this.scheduleFn = i),
            (this.cancelFn = c),
            !o)
          )
            throw new Error('callback is not defined');
          this.callback = o;
          var s = this;
          this.invoke =
            n === D && a && a.useG
              ? t.invokeTask
              : function () {
                  return t.invokeTask.call(e, s, this, arguments);
                };
        }
        return (
          (t.invokeTask = function (e, t, n) {
            e || (e = this), I++;
            try {
              return e.runCount++, e.zone.runTask(e, t, n);
            } finally {
              1 == I && m(), I--;
            }
          }),
          Object.defineProperty(t.prototype, 'zone', {
            get: function () {
              return this._zone;
            },
            enumerable: !1,
            configurable: !0,
          }),
          Object.defineProperty(t.prototype, 'state', {
            get: function () {
              return this._state;
            },
            enumerable: !1,
            configurable: !0,
          }),
          (t.prototype.cancelScheduleRequest = function () {
            this._transitionTo(b, T);
          }),
          (t.prototype._transitionTo = function (e, t, n) {
            if (this._state !== t && this._state !== n)
              throw new Error(
                ''
                  .concat(this.type, " '")
                  .concat(this.source, "': can not transition to '")
                  .concat(e, "', expecting state '")
                  .concat(t, "'")
                  .concat(n ? " or '" + n + "'" : '', ", was '")
                  .concat(this._state, "'.")
              );
            (this._state = e), e == b && (this._zoneDelegates = null);
          }),
          (t.prototype.toString = function () {
            return this.data && void 0 !== this.data.handleId ? this.data.handleId.toString() : Object.prototype.toString.call(this);
          }),
          (t.prototype.toJSON = function () {
            return { type: this.type, state: this.state, source: this.source, zone: this.zone.name, runCount: this.runCount };
          }),
          t
        );
      })(),
      p = a('setTimeout'),
      h = a('Promise'),
      d = a('then'),
      v = [],
      g = !1;
    function y(t) {
      if ((s || (e[h] && (s = e[h].resolve(0))), s)) {
        var n = s[d];
        n || (n = s.then), n.call(s, t);
      } else e[p](t, 0);
    }
    function _(e) {
      0 === I && 0 === v.length && y(m), e && v.push(e);
    }
    function m() {
      if (!g) {
        for (g = !0; v.length; ) {
          var e = v;
          v = [];
          for (var t = 0; t < e.length; t++) {
            var n = e[t];
            try {
              n.zone.runTask(n, null, null);
            } catch (e) {
              C.onUnhandledError(e);
            }
          }
        }
        C.microtaskDrainDone(), (g = !1);
      }
    }
    var k = { name: 'NO ZONE' },
      b = 'notScheduled',
      T = 'scheduling',
      E = 'scheduled',
      w = 'running',
      O = 'canceling',
      S = 'unknown',
      P = 'microTask',
      Z = 'macroTask',
      D = 'eventTask',
      j = {},
      C = {
        symbol: a,
        currentZoneFrame: function () {
          return z;
        },
        onUnhandledError: R,
        microtaskDrainDone: R,
        scheduleMicroTask: _,
        showUncaughtError: function () {
          return !c[a('ignoreConsoleErrorUncaughtError')];
        },
        patchEventTarget: function () {
          return [];
        },
        patchOnProperties: R,
        patchMethod: function () {
          return R;
        },
        bindArguments: function () {
          return [];
        },
        patchThen: function () {
          return R;
        },
        patchMacroTask: function () {
          return R;
        },
        patchEventPrototype: function () {
          return R;
        },
        isIEOrEdge: function () {
          return !1;
        },
        getGlobalObjects: function () {},
        ObjectDefineProperty: function () {
          return R;
        },
        ObjectGetOwnPropertyDescriptor: function () {},
        ObjectCreate: function () {},
        ArraySlice: function () {
          return [];
        },
        patchClass: function () {
          return R;
        },
        wrapWithCurrentZone: function () {
          return R;
        },
        filterProperties: function () {
          return [];
        },
        attachOriginToPatched: function () {
          return R;
        },
        _redefineProperty: function () {
          return R;
        },
        patchCallbacks: function () {
          return R;
        },
        nativeScheduleMicroTask: y,
      },
      z = { parent: null, zone: new c(null, null) },
      M = null,
      I = 0;
    function R() {}
    r('Zone', 'Zone'), (e.Zone = c);
  })(('undefined' != typeof window && window) || ('undefined' != typeof self && self) || global);
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */
  var e = Object.getOwnPropertyDescriptor,
    t = Object.defineProperty,
    n = Object.getPrototypeOf,
    r = Object.create,
    o = Array.prototype.slice,
    a = 'addEventListener',
    i = 'removeEventListener',
    c = Zone.__symbol__(a),
    s = Zone.__symbol__(i),
    u = 'true',
    l = 'false',
    f = Zone.__symbol__('');
  function p(e, t) {
    return Zone.current.wrap(e, t);
  }
  function h(e, t, n, r, o) {
    return Zone.current.scheduleMacroTask(e, t, n, r, o);
  }
  var d = Zone.__symbol__,
    v = 'undefined' != typeof window,
    g = v ? window : void 0,
    y = (v && g) || ('object' == typeof self && self) || global;
  function _(e, t) {
    for (var n = e.length - 1; n >= 0; n--) 'function' == typeof e[n] && (e[n] = p(e[n], t + '_' + n));
    return e;
  }
  function m(e) {
    return !e || (!1 !== e.writable && !('function' == typeof e.get && void 0 === e.set));
  }
  var k = 'undefined' != typeof WorkerGlobalScope && self instanceof WorkerGlobalScope,
    b = !('nw' in y) && void 0 !== y.process && '[object process]' === {}.toString.call(y.process),
    T = !b && !k && !(!v || !g.HTMLElement),
    E = void 0 !== y.process && '[object process]' === {}.toString.call(y.process) && !k && !(!v || !g.HTMLElement),
    w = {},
    O = function (e) {
      if ((e = e || y.event)) {
        var t = w[e.type];
        t || (t = w[e.type] = d('ON_PROPERTY' + e.type));
        var n,
          r = this || e.target || y,
          o = r[t];
        if (T && r === g && 'error' === e.type) {
          var a = e;
          !0 === (n = o && o.call(this, a.message, a.filename, a.lineno, a.colno, a.error)) && e.preventDefault();
        } else null == (n = o && o.apply(this, arguments)) || n || e.preventDefault();
        return n;
      }
    };
  function S(n, r, o) {
    var a = e(n, r);
    if ((!a && o && e(o, r) && (a = { enumerable: !0, configurable: !0 }), a && a.configurable)) {
      var i = d('on' + r + 'patched');
      if (!n.hasOwnProperty(i) || !n[i]) {
        delete a.writable, delete a.value;
        var c = a.get,
          s = a.set,
          u = r.slice(2),
          l = w[u];
        l || (l = w[u] = d('ON_PROPERTY' + u)),
          (a.set = function (e) {
            var t = this;
            t || n !== y || (t = y), t && ('function' == typeof t[l] && t.removeEventListener(u, O), s && s.call(t, null), (t[l] = e), 'function' == typeof e && t.addEventListener(u, O, !1));
          }),
          (a.get = function () {
            var e = this;
            if ((e || n !== y || (e = y), !e)) return null;
            var t = e[l];
            if (t) return t;
            if (c) {
              var o = c.call(this);
              if (o) return a.set.call(this, o), 'function' == typeof e.removeAttribute && e.removeAttribute(r), o;
            }
            return null;
          }),
          t(n, r, a),
          (n[i] = !0);
      }
    }
  }
  function P(e, t, n) {
    if (t) for (var r = 0; r < t.length; r++) S(e, 'on' + t[r], n);
    else {
      var o = [];
      for (var a in e) 'on' == a.slice(0, 2) && o.push(a);
      for (var i = 0; i < o.length; i++) S(e, o[i], n);
    }
  }
  var Z = d('originalInstance');
  function D(e) {
    var n = y[e];
    if (n) {
      (y[d(e)] = n),
        (y[e] = function () {
          var t = _(arguments, e);
          switch (t.length) {
            case 0:
              this[Z] = new n();
              break;
            case 1:
              this[Z] = new n(t[0]);
              break;
            case 2:
              this[Z] = new n(t[0], t[1]);
              break;
            case 3:
              this[Z] = new n(t[0], t[1], t[2]);
              break;
            case 4:
              this[Z] = new n(t[0], t[1], t[2], t[3]);
              break;
            default:
              throw new Error('Arg list too long.');
          }
        }),
        z(y[e], n);
      var r,
        o = new n(function () {});
      for (r in o)
        ('XMLHttpRequest' === e && 'responseBlob' === r) ||
          (function (n) {
            'function' == typeof o[n]
              ? (y[e].prototype[n] = function () {
                  return this[Z][n].apply(this[Z], arguments);
                })
              : t(y[e].prototype, n, {
                  set: function (t) {
                    'function' == typeof t ? ((this[Z][n] = p(t, e + '.' + n)), z(this[Z][n], t)) : (this[Z][n] = t);
                  },
                  get: function () {
                    return this[Z][n];
                  },
                });
          })(r);
      for (r in n) 'prototype' !== r && n.hasOwnProperty(r) && (y[e][r] = n[r]);
    }
  }
  function j(t, r, o) {
    for (var a = t; a && !a.hasOwnProperty(r); ) a = n(a);
    !a && t[r] && (a = t);
    var i = d(r),
      c = null;
    if (a && (!(c = a[i]) || !a.hasOwnProperty(i)) && ((c = a[i] = a[r]), m(a && e(a, r)))) {
      var s = o(c, i, r);
      (a[r] = function () {
        return s(this, arguments);
      }),
        z(a[r], c);
    }
    return c;
  }
  function C(e, t, n) {
    var r = null;
    function o(e) {
      var t = e.data;
      return (
        (t.args[t.cbIdx] = function () {
          e.invoke.apply(this, arguments);
        }),
        r.apply(t.target, t.args),
        e
      );
    }
    r = j(e, t, function (e) {
      return function (t, r) {
        var a = n(t, r);
        return a.cbIdx >= 0 && 'function' == typeof r[a.cbIdx] ? h(a.name, r[a.cbIdx], a, o) : e.apply(t, r);
      };
    });
  }
  function z(e, t) {
    e[d('OriginalDelegate')] = t;
  }
  var M = !1,
    I = !1;
  function R() {
    if (M) return I;
    M = !0;
    try {
      var e = g.navigator.userAgent;
      (-1 === e.indexOf('MSIE ') && -1 === e.indexOf('Trident/') && -1 === e.indexOf('Edge/')) || (I = !0);
    } catch (e) {}
    return I;
  }
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */ Zone.__load_patch('ZoneAwarePromise', function (e, t, n) {
    var r = Object.getOwnPropertyDescriptor,
      o = Object.defineProperty,
      a = n.symbol,
      i = [],
      c = !0 === e[a('DISABLE_WRAPPING_UNCAUGHT_PROMISE_REJECTION')],
      s = a('Promise'),
      u = a('then');
    (n.onUnhandledError = function (e) {
      if (n.showUncaughtError()) {
        var t = e && e.rejection;
        t
          ? console.error('Unhandled Promise rejection:', t instanceof Error ? t.message : t, '; Zone:', e.zone.name, '; Task:', e.task && e.task.source, '; Value:', t, t instanceof Error ? t.stack : void 0)
          : console.error(e);
      }
    }),
      (n.microtaskDrainDone = function () {
        for (
          var e = function () {
            var e = i.shift();
            try {
              e.zone.runGuarded(function () {
                if (e.throwOriginal) throw e.rejection;
                throw e;
              });
            } catch (e) {
              !(function r(e) {
                n.onUnhandledError(e);
                try {
                  var r = t[l];
                  'function' == typeof r && r.call(this, e);
                } catch (e) {}
              })(e);
            }
          };
          i.length;

        )
          e();
      });
    var l = a('unhandledPromiseRejectionHandler');
    function f(e) {
      return e && e.then;
    }
    function p(e) {
      return e;
    }
    function h(e) {
      return z.reject(e);
    }
    var d = a('state'),
      v = a('value'),
      g = a('finally'),
      y = a('parentPromiseValue'),
      _ = a('parentPromiseState'),
      m = null,
      k = !0,
      b = !1;
    function T(e, t) {
      return function (n) {
        try {
          O(e, t, n);
        } catch (t) {
          O(e, !1, t);
        }
      };
    }
    var E = function () {
        var e = !1;
        return function t(n) {
          return function () {
            e || ((e = !0), n.apply(null, arguments));
          };
        };
      },
      w = a('currentTaskTrace');
    function O(e, r, a) {
      var s = E();
      if (e === a) throw new TypeError('Promise resolved with itself');
      if (e[d] === m) {
        var u = null;
        try {
          ('object' != typeof a && 'function' != typeof a) || (u = a && a.then);
        } catch (t) {
          return (
            s(function () {
              O(e, !1, t);
            })(),
            e
          );
        }
        if (r !== b && a instanceof z && a.hasOwnProperty(d) && a.hasOwnProperty(v) && a[d] !== m) P(a), O(e, a[d], a[v]);
        else if (r !== b && 'function' == typeof u)
          try {
            u.call(a, s(T(e, r)), s(T(e, !1)));
          } catch (t) {
            s(function () {
              O(e, !1, t);
            })();
          }
        else {
          e[d] = r;
          var l = e[v];
          if (((e[v] = a), e[g] === g && r === k && ((e[d] = e[_]), (e[v] = e[y])), r === b && a instanceof Error)) {
            var f = t.currentTask && t.currentTask.data && t.currentTask.data.__creationTrace__;
            f && o(a, w, { configurable: !0, enumerable: !1, writable: !0, value: f });
          }
          for (var p = 0; p < l.length; ) Z(e, l[p++], l[p++], l[p++], l[p++]);
          if (0 == l.length && r == b) {
            e[d] = 0;
            var h = a;
            try {
              throw new Error(
                'Uncaught (in promise): ' +
                  (function e(t) {
                    return t && t.toString === Object.prototype.toString ? ((t.constructor && t.constructor.name) || '') + ': ' + JSON.stringify(t) : t ? t.toString() : Object.prototype.toString.call(t);
                  })(a) +
                  (a && a.stack ? '\n' + a.stack : '')
              );
            } catch (e) {
              h = e;
            }
            c && (h.throwOriginal = !0), (h.rejection = a), (h.promise = e), (h.zone = t.current), (h.task = t.currentTask), i.push(h), n.scheduleMicroTask();
          }
        }
      }
      return e;
    }
    var S = a('rejectionHandledHandler');
    function P(e) {
      if (0 === e[d]) {
        try {
          var n = t[S];
          n && 'function' == typeof n && n.call(this, { rejection: e[v], promise: e });
        } catch (e) {}
        e[d] = b;
        for (var r = 0; r < i.length; r++) e === i[r].promise && i.splice(r, 1);
      }
    }
    function Z(e, t, n, r, o) {
      P(e);
      var a = e[d],
        i = a ? ('function' == typeof r ? r : p) : 'function' == typeof o ? o : h;
      t.scheduleMicroTask(
        'Promise.then',
        function () {
          try {
            var r = e[v],
              o = !!n && g === n[g];
            o && ((n[y] = r), (n[_] = a));
            var c = t.run(i, void 0, o && i !== h && i !== p ? [] : [r]);
            O(n, !0, c);
          } catch (e) {
            O(n, !1, e);
          }
        },
        n
      );
    }
    var D = function () {},
      C = e.AggregateError,
      z = (function () {
        function e(t) {
          var n = this;
          if (!(n instanceof e)) throw new Error('Must be an instanceof Promise.');
          (n[d] = m), (n[v] = []);
          try {
            var r = E();
            t && t(r(T(n, k)), r(T(n, b)));
          } catch (e) {
            O(n, !1, e);
          }
        }
        return (
          (e.toString = function () {
            return 'function ZoneAwarePromise() { [native code] }';
          }),
          (e.resolve = function (e) {
            return O(new this(null), k, e);
          }),
          (e.reject = function (e) {
            return O(new this(null), b, e);
          }),
          (e.any = function (t) {
            if (!t || 'function' != typeof t[Symbol.iterator]) return Promise.reject(new C([], 'All promises were rejected'));
            var n = [],
              r = 0;
            try {
              for (var o = 0, a = t; o < a.length; o++) r++, n.push(e.resolve(a[o]));
            } catch (e) {
              return Promise.reject(new C([], 'All promises were rejected'));
            }
            if (0 === r) return Promise.reject(new C([], 'All promises were rejected'));
            var i = !1,
              c = [];
            return new e(function (e, t) {
              for (var o = 0; o < n.length; o++)
                n[o].then(
                  function (t) {
                    i || ((i = !0), e(t));
                  },
                  function (e) {
                    c.push(e), 0 == --r && ((i = !0), t(new C(c, 'All promises were rejected')));
                  }
                );
            });
          }),
          (e.race = function (e) {
            var t,
              n,
              r = new this(function (e, r) {
                (t = e), (n = r);
              });
            function o(e) {
              t(e);
            }
            function a(e) {
              n(e);
            }
            for (var i = 0, c = e; i < c.length; i++) {
              var s = c[i];
              f(s) || (s = this.resolve(s)), s.then(o, a);
            }
            return r;
          }),
          (e.all = function (t) {
            return e.allWithCallback(t);
          }),
          (e.allSettled = function (t) {
            return (this && this.prototype instanceof e ? this : e).allWithCallback(t, {
              thenCallback: function (e) {
                return { status: 'fulfilled', value: e };
              },
              errorCallback: function (e) {
                return { status: 'rejected', reason: e };
              },
            });
          }),
          (e.allWithCallback = function (e, t) {
            for (
              var n,
                r,
                o = new this(function (e, t) {
                  (n = e), (r = t);
                }),
                a = 2,
                i = 0,
                c = [],
                s = function (e) {
                  f(e) || (e = u.resolve(e));
                  var o = i;
                  try {
                    e.then(
                      function (e) {
                        (c[o] = t ? t.thenCallback(e) : e), 0 == --a && n(c);
                      },
                      function (e) {
                        t ? ((c[o] = t.errorCallback(e)), 0 == --a && n(c)) : r(e);
                      }
                    );
                  } catch (e) {
                    r(e);
                  }
                  a++, i++;
                },
                u = this,
                l = 0,
                p = e;
              l < p.length;
              l++
            )
              s(p[l]);
            return 0 == (a -= 2) && n(c), o;
          }),
          Object.defineProperty(e.prototype, Symbol.toStringTag, {
            get: function () {
              return 'Promise';
            },
            enumerable: !1,
            configurable: !0,
          }),
          Object.defineProperty(e.prototype, Symbol.species, {
            get: function () {
              return e;
            },
            enumerable: !1,
            configurable: !0,
          }),
          (e.prototype.then = function (n, r) {
            var o,
              a = null === (o = this.constructor) || void 0 === o ? void 0 : o[Symbol.species];
            (a && 'function' == typeof a) || (a = this.constructor || e);
            var i = new a(D),
              c = t.current;
            return this[d] == m ? this[v].push(c, i, n, r) : Z(this, c, i, n, r), i;
          }),
          (e.prototype.catch = function (e) {
            return this.then(null, e);
          }),
          (e.prototype.finally = function (n) {
            var r,
              o = null === (r = this.constructor) || void 0 === r ? void 0 : r[Symbol.species];
            (o && 'function' == typeof o) || (o = e);
            var a = new o(D);
            a[g] = g;
            var i = t.current;
            return this[d] == m ? this[v].push(i, a, n, n) : Z(this, i, a, n, n), a;
          }),
          e
        );
      })();
    (z.resolve = z.resolve), (z.reject = z.reject), (z.race = z.race), (z.all = z.all);
    var M = (e[s] = e.Promise);
    e.Promise = z;
    var I = a('thenPatched');
    function R(e) {
      var t = e.prototype,
        n = r(t, 'then');
      if (!n || (!1 !== n.writable && n.configurable)) {
        var o = t.then;
        (t[u] = o),
          (e.prototype.then = function (e, t) {
            var n = this;
            return new z(function (e, t) {
              o.call(n, e, t);
            }).then(e, t);
          }),
          (e[I] = !0);
      }
    }
    return (
      (n.patchThen = R),
      M &&
        (R(M),
        j(e, 'fetch', function (e) {
          return (function t(e) {
            return function (t, n) {
              var r = e.apply(t, n);
              if (r instanceof z) return r;
              var o = r.constructor;
              return o[I] || R(o), r;
            };
          })(e);
        })),
      (Promise[t.__symbol__('uncaughtPromiseErrors')] = i),
      z
    );
  }),
    /**
     * @license
     * Copyright Google LLC All Rights Reserved.
     *
     * Use of this source code is governed by an MIT-style license that can be
     * found in the LICENSE file at https://angular.io/license
     */
    Zone.__load_patch('toString', function (e) {
      var t = Function.prototype.toString,
        n = d('OriginalDelegate'),
        r = d('Promise'),
        o = d('Error'),
        a = function a() {
          if ('function' == typeof this) {
            var i = this[n];
            if (i) return 'function' == typeof i ? t.call(i) : Object.prototype.toString.call(i);
            if (this === Promise) {
              var c = e[r];
              if (c) return t.call(c);
            }
            if (this === Error) {
              var s = e[o];
              if (s) return t.call(s);
            }
          }
          return t.call(this);
        };
      (a[n] = t), (Function.prototype.toString = a);
      var i = Object.prototype.toString;
      Object.prototype.toString = function () {
        return 'function' == typeof Promise && this instanceof Promise ? '[object Promise]' : i.call(this);
      };
    });
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */
  var L = !1;
  if ('undefined' != typeof window)
    try {
      var A = Object.defineProperty({}, 'passive', {
        get: function () {
          L = !0;
        },
      });
      window.addEventListener('test', A, A), window.removeEventListener('test', A, A);
    } catch (e) {
      L = !1;
    }
  var N,
    x,
    F,
    H,
    B,
    G = { useG: !0 },
    W = {},
    q = {},
    U = new RegExp('^' + f + '(\\w+)(true|false)$'),
    V = d('propagationStopped');
  function X(e, t) {
    var n = (t ? t(e) : e) + l,
      r = (t ? t(e) : e) + u,
      o = f + n,
      a = f + r;
    (W[e] = {}), (W[e].false = o), (W[e].true = a);
  }
  function Y(e, t, r, o) {
    var c = (o && o.add) || a,
      s = (o && o.rm) || i,
      p = (o && o.listeners) || 'eventListeners',
      h = (o && o.rmAll) || 'removeAllListeners',
      v = d(c),
      g = '.' + c + ':',
      y = function (e, t, n) {
        if (!e.isRemoved) {
          var r,
            o = e.callback;
          'object' == typeof o &&
            o.handleEvent &&
            ((e.callback = function (e) {
              return o.handleEvent(e);
            }),
            (e.originalDelegate = o));
          try {
            e.invoke(e, t, [n]);
          } catch (e) {
            r = e;
          }
          var a = e.options;
          return a && 'object' == typeof a && a.once && t[s].call(t, n.type, e.originalDelegate ? e.originalDelegate : e.callback, a), r;
        }
      };
    function _(n, r, o) {
      if ((r = r || e.event)) {
        var a = n || r.target || e,
          i = a[W[r.type][o ? u : l]];
        if (i) {
          var c = [];
          if (1 === i.length) (p = y(i[0], a, r)) && c.push(p);
          else
            for (var s = i.slice(), f = 0; f < s.length && (!r || !0 !== r[V]); f++) {
              var p;
              (p = y(s[f], a, r)) && c.push(p);
            }
          if (1 === c.length) throw c[0];
          var h = function (e) {
            var n = c[e];
            t.nativeScheduleMicroTask(function () {
              throw n;
            });
          };
          for (f = 0; f < c.length; f++) h(f);
        }
      }
    }
    var m = function (e) {
        return _(this, e, !1);
      },
      k = function (e) {
        return _(this, e, !0);
      };
    function T(t, r) {
      if (!t) return !1;
      var o = !0;
      r && void 0 !== r.useG && (o = r.useG);
      var a = r && r.vh,
        i = !0;
      r && void 0 !== r.chkDup && (i = r.chkDup);
      var y = !1;
      r && void 0 !== r.rt && (y = r.rt);
      for (var _ = t; _ && !_.hasOwnProperty(c); ) _ = n(_);
      if ((!_ && t[c] && (_ = t), !_)) return !1;
      if (_[v]) return !1;
      var T,
        E = r && r.eventNameToString,
        w = {},
        O = (_[v] = _[c]),
        S = (_[d(s)] = _[s]),
        P = (_[d(p)] = _[p]),
        Z = (_[d(h)] = _[h]);
      function D(e, t) {
        return !L && 'object' == typeof e && e
          ? !!e.capture
          : L && t
          ? 'boolean' == typeof e
            ? { capture: e, passive: !0 }
            : e
            ? 'object' == typeof e && !1 !== e.passive
              ? Object.assign(Object.assign({}, e), { passive: !0 })
              : e
            : { passive: !0 }
          : e;
      }
      r && r.prepend && (T = _[d(r.prepend)] = _[r.prepend]);
      var j = o
          ? function (e) {
              if (!w.isExisting) return O.call(w.target, w.eventName, w.capture ? k : m, w.options);
            }
          : function (e) {
              return O.call(w.target, w.eventName, e.invoke, w.options);
            },
        C = o
          ? function (e) {
              if (!e.isRemoved) {
                var t = W[e.eventName],
                  n = void 0;
                t && (n = t[e.capture ? u : l]);
                var r = n && e.target[n];
                if (r)
                  for (var o = 0; o < r.length; o++)
                    if (r[o] === e) {
                      r.splice(o, 1), (e.isRemoved = !0), 0 === r.length && ((e.allRemoved = !0), (e.target[n] = null));
                      break;
                    }
              }
              if (e.allRemoved) return S.call(e.target, e.eventName, e.capture ? k : m, e.options);
            }
          : function (e) {
              return S.call(e.target, e.eventName, e.invoke, e.options);
            },
        M =
          r && r.diff
            ? r.diff
            : function (e, t) {
                var n = typeof t;
                return ('function' === n && e.callback === t) || ('object' === n && e.originalDelegate === t);
              },
        I = Zone[d('UNPATCHED_EVENTS')],
        R = e[d('PASSIVE_EVENTS')],
        A = function (t, n, c, s, f, p) {
          return (
            void 0 === f && (f = !1),
            void 0 === p && (p = !1),
            function () {
              var h = this || e,
                d = arguments[0];
              r && r.transferEventName && (d = r.transferEventName(d));
              var v = arguments[1];
              if (!v) return t.apply(this, arguments);
              if (b && 'uncaughtException' === d) return t.apply(this, arguments);
              var g = !1;
              if ('function' != typeof v) {
                if (!v.handleEvent) return t.apply(this, arguments);
                g = !0;
              }
              if (!a || a(t, v, h, arguments)) {
                var y = L && !!R && -1 !== R.indexOf(d),
                  _ = D(arguments[2], y);
                if (I) for (var m = 0; m < I.length; m++) if (d === I[m]) return y ? t.call(h, d, v, _) : t.apply(this, arguments);
                var k = !!_ && ('boolean' == typeof _ || _.capture),
                  T = !(!_ || 'object' != typeof _) && _.once,
                  O = Zone.current,
                  S = W[d];
                S || (X(d, E), (S = W[d]));
                var P,
                  Z = S[k ? u : l],
                  j = h[Z],
                  C = !1;
                if (j) {
                  if (((C = !0), i)) for (m = 0; m < j.length; m++) if (M(j[m], v)) return;
                } else j = h[Z] = [];
                var z = h.constructor.name,
                  A = q[z];
                A && (P = A[d]), P || (P = z + n + (E ? E(d) : d)), (w.options = _), T && (w.options.once = !1), (w.target = h), (w.capture = k), (w.eventName = d), (w.isExisting = C);
                var N = o ? G : void 0;
                N && (N.taskData = w);
                var x = O.scheduleEventTask(P, v, N, c, s);
                return (
                  (w.target = null),
                  N && (N.taskData = null),
                  T && (_.once = !0),
                  (L || 'boolean' != typeof x.options) && (x.options = _),
                  (x.target = h),
                  (x.capture = k),
                  (x.eventName = d),
                  g && (x.originalDelegate = v),
                  p ? j.unshift(x) : j.push(x),
                  f ? h : void 0
                );
              }
            }
          );
        };
      return (
        (_[c] = A(O, g, j, C, y)),
        T &&
          (_.prependListener = A(
            T,
            '.prependListener:',
            function (e) {
              return T.call(w.target, w.eventName, e.invoke, w.options);
            },
            C,
            y,
            !0
          )),
        (_[s] = function () {
          var t = this || e,
            n = arguments[0];
          r && r.transferEventName && (n = r.transferEventName(n));
          var o = arguments[2],
            i = !!o && ('boolean' == typeof o || o.capture),
            c = arguments[1];
          if (!c) return S.apply(this, arguments);
          if (!a || a(S, c, t, arguments)) {
            var s,
              p = W[n];
            p && (s = p[i ? u : l]);
            var h = s && t[s];
            if (h)
              for (var d = 0; d < h.length; d++) {
                var v = h[d];
                if (M(v, c)) {
                  if ((h.splice(d, 1), (v.isRemoved = !0), 0 === h.length && ((v.allRemoved = !0), (t[s] = null), 'string' == typeof n))) {
                    var g = f + 'ON_PROPERTY' + n;
                    t[g] = null;
                  }
                  return v.zone.cancelTask(v), y ? t : void 0;
                }
              }
            return S.apply(this, arguments);
          }
        }),
        (_[p] = function () {
          var t = this || e,
            n = arguments[0];
          r && r.transferEventName && (n = r.transferEventName(n));
          for (var o = [], a = J(t, E ? E(n) : n), i = 0; i < a.length; i++) {
            var c = a[i],
              s = c.originalDelegate ? c.originalDelegate : c.callback;
            o.push(s);
          }
          return o;
        }),
        (_[h] = function () {
          var t = this || e,
            n = arguments[0];
          if (n) {
            r && r.transferEventName && (n = r.transferEventName(n));
            var o = W[n];
            if (o) {
              var a = o.false,
                i = o.true,
                c = t[a],
                u = t[i];
              if (c) {
                var l = c.slice();
                for (d = 0; d < l.length; d++) this[s].call(this, n, (f = l[d]).originalDelegate ? f.originalDelegate : f.callback, f.options);
              }
              if (u)
                for (l = u.slice(), d = 0; d < l.length; d++) {
                  var f;
                  this[s].call(this, n, (f = l[d]).originalDelegate ? f.originalDelegate : f.callback, f.options);
                }
            }
          } else {
            for (var p = Object.keys(t), d = 0; d < p.length; d++) {
              var v = p[d],
                g = U.exec(v),
                _ = g && g[1];
              _ && 'removeListener' !== _ && this[h].call(this, _);
            }
            this[h].call(this, 'removeListener');
          }
          if (y) return this;
        }),
        z(_[c], O),
        z(_[s], S),
        Z && z(_[h], Z),
        P && z(_[p], P),
        !0
      );
    }
    for (var E = [], w = 0; w < r.length; w++) E[w] = T(r[w], o);
    return E;
  }
  function J(e, t) {
    if (!t) {
      var n = [];
      for (var r in e) {
        var o = U.exec(r),
          a = o && o[1];
        if (a && (!t || a === t)) {
          var i = e[r];
          if (i) for (var c = 0; c < i.length; c++) n.push(i[c]);
        }
      }
      return n;
    }
    var s = W[t];
    s || (X(t), (s = W[t]));
    var u = e[s.false],
      l = e[s.true];
    return u ? (l ? u.concat(l) : u.slice()) : l ? l.slice() : [];
  }
  function K(e, t) {
    var n = e.Event;
    n &&
      n.prototype &&
      t.patchMethod(n.prototype, 'stopImmediatePropagation', function (e) {
        return function (t, n) {
          (t[V] = !0), e && e.apply(t, n);
        };
      });
  }
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */ function Q(e, t, n, r, o) {
    var a = Zone.__symbol__(r);
    if (!t[a]) {
      var i = (t[a] = t[r]);
      (t[r] = function (a, c, s) {
        return (
          c &&
            c.prototype &&
            o.forEach(function (t) {
              var o = ''.concat(n, '.').concat(r, '::') + t,
                a = c.prototype;
              try {
                if (a.hasOwnProperty(t)) {
                  var i = e.ObjectGetOwnPropertyDescriptor(a, t);
                  i && i.value ? ((i.value = e.wrapWithCurrentZone(i.value, o)), e._redefineProperty(c.prototype, t, i)) : a[t] && (a[t] = e.wrapWithCurrentZone(a[t], o));
                } else a[t] && (a[t] = e.wrapWithCurrentZone(a[t], o));
              } catch (e) {}
            }),
          i.call(t, a, c, s)
        );
      }),
        e.attachOriginToPatched(t[r], i);
    }
  }
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */ function $(e, t, n) {
    if (!n || 0 === n.length) return t;
    var r = n.filter(function (t) {
      return t.target === e;
    });
    if (!r || 0 === r.length) return t;
    var o = r[0].ignoreProperties;
    return t.filter(function (e) {
      return -1 === o.indexOf(e);
    });
  }
  function ee(e, t, n, r) {
    e && P(e, $(e, t, n), r);
  }
  function te(e) {
    return Object.getOwnPropertyNames(e)
      .filter(function (e) {
        return e.startsWith('on') && e.length > 2;
      })
      .map(function (e) {
        return e.substring(2);
      });
  }
  function ne(e, t) {
    if ((!b || E) && !Zone[e.symbol('patchEvents')]) {
      var r = t.__Zone_ignore_on_properties,
        o = [];
      if (T) {
        var a = window;
        o = o.concat(['Document', 'SVGElement', 'Element', 'HTMLElement', 'HTMLBodyElement', 'HTMLMediaElement', 'HTMLFrameSetElement', 'HTMLFrameElement', 'HTMLIFrameElement', 'HTMLMarqueeElement', 'Worker']);
        var i = (function e() {
          try {
            var e = g.navigator.userAgent;
            if (-1 !== e.indexOf('MSIE ') || -1 !== e.indexOf('Trident/')) return !0;
          } catch (e) {}
          return !1;
        })()
          ? [{ target: a, ignoreProperties: ['error'] }]
          : [];
        ee(a, te(a), r ? r.concat(i) : r, n(a));
      }
      o = o.concat(['XMLHttpRequest', 'XMLHttpRequestEventTarget', 'IDBIndex', 'IDBRequest', 'IDBOpenDBRequest', 'IDBDatabase', 'IDBTransaction', 'IDBCursor', 'WebSocket']);
      for (var c = 0; c < o.length; c++) {
        var s = t[o[c]];
        s && s.prototype && ee(s.prototype, te(s.prototype), r);
      }
    }
  }
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */ function re() {
    (N = Zone.__symbol__),
      (x = Object[N('defineProperty')] = Object.defineProperty),
      (F = Object[N('getOwnPropertyDescriptor')] = Object.getOwnPropertyDescriptor),
      (H = Object.create),
      (B = N('unconfigurables')),
      (Object.defineProperty = function (e, t, n) {
        if (ae(e, t)) throw new TypeError("Cannot assign to read only property '" + t + "' of " + e);
        var r = n.configurable;
        return 'prototype' !== t && (n = ie(e, t, n)), ce(e, t, n, r);
      }),
      (Object.defineProperties = function (e, t) {
        Object.keys(t).forEach(function (n) {
          Object.defineProperty(e, n, t[n]);
        });
        for (var n = 0, r = Object.getOwnPropertySymbols(t); n < r.length; n++) {
          var o = r[n],
            a = Object.getOwnPropertyDescriptor(t, o);
          (null == a ? void 0 : a.enumerable) && Object.defineProperty(e, o, t[o]);
        }
        return e;
      }),
      (Object.create = function (e, t) {
        return (
          'object' != typeof t ||
            Object.isFrozen(t) ||
            Object.keys(t).forEach(function (n) {
              t[n] = ie(e, n, t[n]);
            }),
          H(e, t)
        );
      }),
      (Object.getOwnPropertyDescriptor = function (e, t) {
        var n = F(e, t);
        return n && ae(e, t) && (n.configurable = !1), n;
      });
  }
  function oe(e, t, n) {
    var r = n.configurable;
    return ce(e, t, (n = ie(e, t, n)), r);
  }
  function ae(e, t) {
    return e && e[B] && e[B][t];
  }
  function ie(e, t, n) {
    return Object.isFrozen(n) || (n.configurable = !0), n.configurable || (e[B] || Object.isFrozen(e) || x(e, B, { writable: !0, value: {} }), e[B] && (e[B][t] = !0)), n;
  }
  function ce(e, t, n, r) {
    try {
      return x(e, t, n);
    } catch (i) {
      if (!n.configurable) throw i;
      void 0 === r ? delete n.configurable : (n.configurable = r);
      try {
        return x(e, t, n);
      } catch (r) {
        var o = !1;
        if ((('createdCallback' !== t && 'attachedCallback' !== t && 'detachedCallback' !== t && 'attributeChangedCallback' !== t) || (o = !0), !o)) throw r;
        var a = null;
        try {
          a = JSON.stringify(n);
        } catch (e) {
          a = n.toString();
        }
        console.log("Attempting to configure '".concat(t, "' with descriptor '").concat(a, "' on object '").concat(e, "' and got error, giving up: ").concat(r));
      }
    }
  }
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */ function se(e, t) {
    var n = t.getGlobalObjects(),
      r = n.eventNames,
      o = n.globalSources,
      a = n.zoneSymbolEventNames,
      i = n.TRUE_STR,
      c = n.FALSE_STR,
      s = n.ZONE_SYMBOL_PREFIX,
      u =
        'ApplicationCache,EventSource,FileReader,InputMethodContext,MediaController,MessagePort,Node,Performance,SVGElementInstance,SharedWorker,TextTrack,TextTrackCue,TextTrackList,WebKitNamedFlow,Window,Worker,WorkerGlobalScope,XMLHttpRequest,XMLHttpRequestEventTarget,XMLHttpRequestUpload,IDBRequest,IDBOpenDBRequest,IDBDatabase,IDBTransaction,IDBCursor,DBIndex,WebSocket'.split(
          ','
        ),
      l = [],
      f = e.wtf,
      p =
        'Anchor,Area,Audio,BR,Base,BaseFont,Body,Button,Canvas,Content,DList,Directory,Div,Embed,FieldSet,Font,Form,Frame,FrameSet,HR,Head,Heading,Html,IFrame,Image,Input,Keygen,LI,Label,Legend,Link,Map,Marquee,Media,Menu,Meta,Meter,Mod,OList,Object,OptGroup,Option,Output,Paragraph,Pre,Progress,Quote,Script,Select,Source,Span,Style,TableCaption,TableCell,TableCol,Table,TableRow,TableSection,TextArea,Title,Track,UList,Unknown,Video'.split(
          ','
        );
    f
      ? (l = p
          .map(function (e) {
            return 'HTML' + e + 'Element';
          })
          .concat(u))
      : e.EventTarget
      ? l.push('EventTarget')
      : (l = u);
    for (
      var h = e.__Zone_disable_IE_check || !1,
        d = e.__Zone_enable_cross_context_check || !1,
        v = t.isIEOrEdge(),
        g = '[object FunctionWrapper]',
        y = 'function __BROWSERTOOLS_CONSOLE_SAFEFUNC() { [native code] }',
        _ = {
          MSPointerCancel: 'pointercancel',
          MSPointerDown: 'pointerdown',
          MSPointerEnter: 'pointerenter',
          MSPointerHover: 'pointerhover',
          MSPointerLeave: 'pointerleave',
          MSPointerMove: 'pointermove',
          MSPointerOut: 'pointerout',
          MSPointerOver: 'pointerover',
          MSPointerUp: 'pointerup',
        },
        m = 0;
      m < r.length;
      m++
    ) {
      var k = s + ((O = r[m]) + c),
        b = s + (O + i);
      (a[O] = {}), (a[O][c] = k), (a[O][i] = b);
    }
    for (m = 0; m < p.length; m++)
      for (var T = p[m], E = (o[T] = {}), w = 0; w < r.length; w++) {
        var O;
        E[(O = r[w])] = T + '.addEventListener:' + O;
      }
    var S = [];
    for (m = 0; m < l.length; m++) {
      var P = e[l[m]];
      S.push(P && P.prototype);
    }
    return (
      t.patchEventTarget(e, t, S, {
        vh: function (e, t, n, r) {
          if (!h && v) {
            if (d)
              try {
                var o;
                if ((o = t.toString()) === g || o == y) return e.apply(n, r), !1;
              } catch (t) {
                return e.apply(n, r), !1;
              }
            else if ((o = t.toString()) === g || o == y) return e.apply(n, r), !1;
          } else if (d)
            try {
              t.toString();
            } catch (t) {
              return e.apply(n, r), !1;
            }
          return !0;
        },
        transferEventName: function (e) {
          return _[e] || e;
        },
      }),
      (Zone[t.symbol('patchEventTarget')] = !!e.EventTarget),
      !0
    );
  }
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */
  function ue(e, t) {
    var n = e.getGlobalObjects();
    if (
      (!n.isNode || n.isMix) &&
      !(function r(e, t) {
        var n = e.getGlobalObjects();
        if ((n.isBrowser || n.isMix) && !e.ObjectGetOwnPropertyDescriptor(HTMLElement.prototype, 'onclick') && 'undefined' != typeof Element) {
          var r = e.ObjectGetOwnPropertyDescriptor(Element.prototype, 'onclick');
          if (r && !r.configurable) return !1;
          if (r) {
            e.ObjectDefineProperty(Element.prototype, 'onclick', {
              enumerable: !0,
              configurable: !0,
              get: function () {
                return !0;
              },
            });
            var o = !!document.createElement('div').onclick;
            return e.ObjectDefineProperty(Element.prototype, 'onclick', r), o;
          }
        }
        var a = t.XMLHttpRequest;
        if (!a) return !1;
        var i = 'onreadystatechange',
          c = a.prototype,
          s = e.ObjectGetOwnPropertyDescriptor(c, i);
        if (s)
          return (
            e.ObjectDefineProperty(c, i, {
              enumerable: !0,
              configurable: !0,
              get: function () {
                return !0;
              },
            }),
            (o = !!(l = new a()).onreadystatechange),
            e.ObjectDefineProperty(c, i, s || {}),
            o
          );
        var u = e.symbol('fake');
        e.ObjectDefineProperty(c, i, {
          enumerable: !0,
          configurable: !0,
          get: function () {
            return this[u];
          },
          set: function (e) {
            this[u] = e;
          },
        });
        var l,
          f = function () {};
        return ((l = new a()).onreadystatechange = f), (o = l[u] === f), (l.onreadystatechange = null), o;
      })(e, t)
    ) {
      var o = 'undefined' != typeof WebSocket;
      !(function n(e) {
        for (
          var t = e.symbol('unbound'),
            n = function (n) {
              var r = le[n],
                o = 'on' + r;
              self.addEventListener(
                r,
                function (n) {
                  var r,
                    a,
                    i = n.target;
                  for (a = i ? i.constructor.name + '.' + o : 'unknown.' + o; i; ) i[o] && !i[o][t] && (((r = e.wrapWithCurrentZone(i[o], a))[t] = i[o]), (i[o] = r)), (i = i.parentElement);
                },
                !0
              );
            },
            r = 0;
          r < le.length;
          r++
        )
          n(r);
      })(
        /**
         * @license
         * Copyright Google LLC All Rights Reserved.
         *
         * Use of this source code is governed by an MIT-style license that can be
         * found in the LICENSE file at https://angular.io/license
         */ e
      ),
        e.patchClass('XMLHttpRequest'),
        o &&
          (function r(e, t) {
            var n = e.getGlobalObjects(),
              r = n.ADD_EVENT_LISTENER_STR,
              o = n.REMOVE_EVENT_LISTENER_STR,
              a = t.WebSocket;
            t.EventTarget || e.patchEventTarget(t, e, [a.prototype]),
              (t.WebSocket = function (t, n) {
                var i,
                  c,
                  s = arguments.length > 1 ? new a(t, n) : new a(t),
                  u = e.ObjectGetOwnPropertyDescriptor(s, 'onmessage');
                return (
                  u && !1 === u.configurable
                    ? ((i = e.ObjectCreate(s)),
                      (c = s),
                      [r, o, 'send', 'close'].forEach(function (t) {
                        i[t] = function () {
                          var n = e.ArraySlice.call(arguments);
                          if (t === r || t === o) {
                            var a = n.length > 0 ? n[0] : void 0;
                            if (a) {
                              var c = Zone.__symbol__('ON_PROPERTY' + a);
                              s[c] = i[c];
                            }
                          }
                          return s[t].apply(s, n);
                        };
                      }))
                    : (i = s),
                  e.patchOnProperties(i, ['close', 'error', 'message', 'open'], c),
                  i
                );
              });
            var i = t.WebSocket;
            for (var c in a) i[c] = a[c];
          })(e, t),
        (Zone[e.symbol('patchEvents')] = !0);
    }
  }
  Zone.__load_patch('util', function (n, c, s) {
    var h = te(n);
    (s.patchOnProperties = P), (s.patchMethod = j), (s.bindArguments = _), (s.patchMacroTask = C);
    var d = c.__symbol__('BLACK_LISTED_EVENTS'),
      v = c.__symbol__('UNPATCHED_EVENTS');
    n[v] && (n[d] = n[v]),
      n[d] && (c[d] = c[v] = n[d]),
      (s.patchEventPrototype = K),
      (s.patchEventTarget = Y),
      (s.isIEOrEdge = R),
      (s.ObjectDefineProperty = t),
      (s.ObjectGetOwnPropertyDescriptor = e),
      (s.ObjectCreate = r),
      (s.ArraySlice = o),
      (s.patchClass = D),
      (s.wrapWithCurrentZone = p),
      (s.filterProperties = $),
      (s.attachOriginToPatched = z),
      (s._redefineProperty = Object.defineProperty),
      (s.patchCallbacks = Q),
      (s.getGlobalObjects = function () {
        return {
          globalSources: q,
          zoneSymbolEventNames: W,
          eventNames: h,
          isBrowser: T,
          isMix: E,
          isNode: b,
          TRUE_STR: u,
          FALSE_STR: l,
          ZONE_SYMBOL_PREFIX: f,
          ADD_EVENT_LISTENER_STR: a,
          REMOVE_EVENT_LISTENER_STR: i,
        };
      });
  });
  var le = __spreadArray(
    __spreadArray(
      __spreadArray(
        __spreadArray(
          __spreadArray(
            __spreadArray(
              __spreadArray(
                __spreadArray(
                  [],
                  [
                    'abort',
                    'animationcancel',
                    'animationend',
                    'animationiteration',
                    'auxclick',
                    'beforeinput',
                    'blur',
                    'cancel',
                    'canplay',
                    'canplaythrough',
                    'change',
                    'compositionstart',
                    'compositionupdate',
                    'compositionend',
                    'cuechange',
                    'click',
                    'close',
                    'contextmenu',
                    'curechange',
                    'dblclick',
                    'drag',
                    'dragend',
                    'dragenter',
                    'dragexit',
                    'dragleave',
                    'dragover',
                    'drop',
                    'durationchange',
                    'emptied',
                    'ended',
                    'error',
                    'focus',
                    'focusin',
                    'focusout',
                    'gotpointercapture',
                    'input',
                    'invalid',
                    'keydown',
                    'keypress',
                    'keyup',
                    'load',
                    'loadstart',
                    'loadeddata',
                    'loadedmetadata',
                    'lostpointercapture',
                    'mousedown',
                    'mouseenter',
                    'mouseleave',
                    'mousemove',
                    'mouseout',
                    'mouseover',
                    'mouseup',
                    'mousewheel',
                    'orientationchange',
                    'pause',
                    'play',
                    'playing',
                    'pointercancel',
                    'pointerdown',
                    'pointerenter',
                    'pointerleave',
                    'pointerlockchange',
                    'mozpointerlockchange',
                    'webkitpointerlockerchange',
                    'pointerlockerror',
                    'mozpointerlockerror',
                    'webkitpointerlockerror',
                    'pointermove',
                    'pointout',
                    'pointerover',
                    'pointerup',
                    'progress',
                    'ratechange',
                    'reset',
                    'resize',
                    'scroll',
                    'seeked',
                    'seeking',
                    'select',
                    'selectionchange',
                    'selectstart',
                    'show',
                    'sort',
                    'stalled',
                    'submit',
                    'suspend',
                    'timeupdate',
                    'volumechange',
                    'touchcancel',
                    'touchmove',
                    'touchstart',
                    'touchend',
                    'transitioncancel',
                    'transitionend',
                    'waiting',
                    'wheel',
                  ],
                  !0
                ),
                ['webglcontextrestored', 'webglcontextlost', 'webglcontextcreationerror'],
                !0
              ),
              ['autocomplete', 'autocompleteerror'],
              !0
            ),
            ['toggle'],
            !0
          ),
          [
            'afterscriptexecute',
            'beforescriptexecute',
            'DOMContentLoaded',
            'freeze',
            'fullscreenchange',
            'mozfullscreenchange',
            'webkitfullscreenchange',
            'msfullscreenchange',
            'fullscreenerror',
            'mozfullscreenerror',
            'webkitfullscreenerror',
            'msfullscreenerror',
            'readystatechange',
            'visibilitychange',
            'resume',
          ],
          !0
        ),
        [
          'absolutedeviceorientation',
          'afterinput',
          'afterprint',
          'appinstalled',
          'beforeinstallprompt',
          'beforeprint',
          'beforeunload',
          'devicelight',
          'devicemotion',
          'deviceorientation',
          'deviceorientationabsolute',
          'deviceproximity',
          'hashchange',
          'languagechange',
          'message',
          'mozbeforepaint',
          'offline',
          'online',
          'paint',
          'pageshow',
          'pagehide',
          'popstate',
          'rejectionhandled',
          'storage',
          'unhandledrejection',
          'unload',
          'userproximity',
          'vrdisplayconnected',
          'vrdisplaydisconnected',
          'vrdisplaypresentchange',
        ],
        !0
      ),
      [
        'beforecopy',
        'beforecut',
        'beforepaste',
        'copy',
        'cut',
        'paste',
        'dragstart',
        'loadend',
        'animationstart',
        'search',
        'transitionrun',
        'transitionstart',
        'webkitanimationend',
        'webkitanimationiteration',
        'webkitanimationstart',
        'webkittransitionend',
      ],
      !0
    ),
    [
      'activate',
      'afterupdate',
      'ariarequest',
      'beforeactivate',
      'beforedeactivate',
      'beforeeditfocus',
      'beforeupdate',
      'cellchange',
      'controlselect',
      'dataavailable',
      'datasetchanged',
      'datasetcomplete',
      'errorupdate',
      'filterchange',
      'layoutcomplete',
      'losecapture',
      'move',
      'moveend',
      'movestart',
      'propertychange',
      'resizeend',
      'resizestart',
      'rowenter',
      'rowexit',
      'rowsdelete',
      'rowsinserted',
      'command',
      'compassneedscalibration',
      'deactivate',
      'help',
      'mscontentzoom',
      'msmanipulationstatechanged',
      'msgesturechange',
      'msgesturedoubletap',
      'msgestureend',
      'msgesturehold',
      'msgesturestart',
      'msgesturetap',
      'msgotpointercapture',
      'msinertiastart',
      'mslostpointercapture',
      'mspointercancel',
      'mspointerdown',
      'mspointerenter',
      'mspointerhover',
      'mspointerleave',
      'mspointermove',
      'mspointerout',
      'mspointerover',
      'mspointerup',
      'pointerout',
      'mssitemodejumplistitemremoved',
      'msthumbnailclick',
      'stop',
      'storagecommit',
    ],
    !0
  );
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */
  !(function (e) {
    var t = e.__Zone_symbol_prefix || '__zone_symbol__';
    e[
      (function n(e) {
        return t + e;
      })('legacyPatch')
    ] = function () {
      var t = e.Zone;
      t.__load_patch('defineProperty', function (e, t, n) {
        (n._redefineProperty = oe), re();
      }),
        t.__load_patch('registerElement', function (e, t, n) {
          !(function r(e, t) {
            var n = t.getGlobalObjects();
            (n.isBrowser || n.isMix) &&
              'registerElement' in e.document &&
              t.patchCallbacks(t, document, 'Document', 'registerElement', ['createdCallback', 'attachedCallback', 'detachedCallback', 'attributeChangedCallback']);
          })(e, n);
        }),
        t.__load_patch('EventTargetLegacy', function (e, t, n) {
          se(e, n), ue(n, e);
        });
    };
  })('undefined' != typeof window ? window : 'undefined' != typeof global ? global : 'undefined' != typeof self ? self : {});
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */
  var fe = d('zoneTask');
  function pe(e, t, n, r) {
    var o = null,
      a = null;
    n += r;
    var i = {};
    function c(t) {
      var n = t.data;
      return (
        (n.args[0] = function () {
          return t.invoke.apply(this, arguments);
        }),
        (n.handleId = o.apply(e, n.args)),
        t
      );
    }
    function s(t) {
      return a.call(e, t.data.handleId);
    }
    (o = j(e, (t += r), function (n) {
      return function (o, a) {
        if ('function' == typeof a[0]) {
          var u = { isPeriodic: 'Interval' === r, delay: 'Timeout' === r || 'Interval' === r ? a[1] || 0 : void 0, args: a },
            l = a[0];
          a[0] = function e() {
            try {
              return l.apply(this, arguments);
            } finally {
              u.isPeriodic || ('number' == typeof u.handleId ? delete i[u.handleId] : u.handleId && (u.handleId[fe] = null));
            }
          };
          var f = h(t, a[0], u, c, s);
          if (!f) return f;
          var p = f.data.handleId;
          return (
            'number' == typeof p ? (i[p] = f) : p && (p[fe] = f),
            p && p.ref && p.unref && 'function' == typeof p.ref && 'function' == typeof p.unref && ((f.ref = p.ref.bind(p)), (f.unref = p.unref.bind(p))),
            'number' == typeof p || p ? p : f
          );
        }
        return n.apply(e, a);
      };
    })),
      (a = j(e, n, function (t) {
        return function (n, r) {
          var o,
            a = r[0];
          'number' == typeof a ? (o = i[a]) : (o = a && a[fe]) || (o = a),
            o && 'string' == typeof o.type
              ? 'notScheduled' !== o.state && ((o.cancelFn && o.data.isPeriodic) || 0 === o.runCount) && ('number' == typeof a ? delete i[a] : a && (a[fe] = null), o.zone.cancelTask(o))
              : t.apply(e, r);
        };
      }));
  }
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */
  function he(e, t) {
    if (!Zone[t.symbol('patchEventTarget')]) {
      for (var n = t.getGlobalObjects(), r = n.eventNames, o = n.zoneSymbolEventNames, a = n.TRUE_STR, i = n.FALSE_STR, c = n.ZONE_SYMBOL_PREFIX, s = 0; s < r.length; s++) {
        var u = r[s],
          l = c + (u + i),
          f = c + (u + a);
        (o[u] = {}), (o[u][i] = l), (o[u][a] = f);
      }
      var p = e.EventTarget;
      if (p && p.prototype) return t.patchEventTarget(e, t, [p && p.prototype]), !0;
    }
  }
  /**
   * @license
   * Copyright Google LLC All Rights Reserved.
   *
   * Use of this source code is governed by an MIT-style license that can be
   * found in the LICENSE file at https://angular.io/license
   */
  Zone.__load_patch('legacy', function (e) {
    var t = e[Zone.__symbol__('legacyPatch')];
    t && t();
  }),
    Zone.__load_patch('queueMicrotask', function (e, t, n) {
      n.patchMethod(e, 'queueMicrotask', function (e) {
        return function (e, n) {
          t.current.scheduleMicroTask('queueMicrotask', n[0]);
        };
      });
    }),
    Zone.__load_patch('timers', function (e) {
      var t = 'set',
        n = 'clear';
      pe(e, t, n, 'Timeout'), pe(e, t, n, 'Interval'), pe(e, t, n, 'Immediate');
    }),
    Zone.__load_patch('requestAnimationFrame', function (e) {
      pe(e, 'request', 'cancel', 'AnimationFrame'), pe(e, 'mozRequest', 'mozCancel', 'AnimationFrame'), pe(e, 'webkitRequest', 'webkitCancel', 'AnimationFrame');
    }),
    Zone.__load_patch('blocking', function (e, t) {
      for (var n = ['alert', 'prompt', 'confirm'], r = 0; r < n.length; r++)
        j(e, n[r], function (n, r, o) {
          return function (r, a) {
            return t.current.run(n, e, a, o);
          };
        });
    }),
    Zone.__load_patch('EventTarget', function (e, t, n) {
      !(function r(e, t) {
        t.patchEventPrototype(e, t);
      })(e, n),
        he(e, n);
      var o = e.XMLHttpRequestEventTarget;
      o && o.prototype && n.patchEventTarget(e, n, [o.prototype]);
    }),
    Zone.__load_patch('MutationObserver', function (e, t, n) {
      D('MutationObserver'), D('WebKitMutationObserver');
    }),
    Zone.__load_patch('IntersectionObserver', function (e, t, n) {
      D('IntersectionObserver');
    }),
    Zone.__load_patch('FileReader', function (e, t, n) {
      D('FileReader');
    }),
    Zone.__load_patch('on_property', function (e, t, n) {
      ne(n, e);
    }),
    Zone.__load_patch('customElements', function (e, t, n) {
      !(function r(e, t) {
        var n = t.getGlobalObjects();
        (n.isBrowser || n.isMix) &&
          e.customElements &&
          'customElements' in e &&
          t.patchCallbacks(t, e.customElements, 'customElements', 'define', ['connectedCallback', 'disconnectedCallback', 'adoptedCallback', 'attributeChangedCallback']);
      })(e, n);
    }),
    Zone.__load_patch('XHR', function (e, t) {
      !(function n(e) {
        var n = e.XMLHttpRequest;
        if (n) {
          var f = n.prototype,
            p = f[c],
            v = f[s];
          if (!p) {
            var g = e.XMLHttpRequestEventTarget;
            if (g) {
              var y = g.prototype;
              (p = y[c]), (v = y[s]);
            }
          }
          var _ = 'readystatechange',
            m = 'scheduled',
            k = j(f, 'open', function () {
              return function (e, t) {
                return (e[o] = 0 == t[2]), (e[u] = t[1]), k.apply(e, t);
              };
            }),
            b = d('fetchTaskAborting'),
            T = d('fetchTaskScheduling'),
            E = j(f, 'send', function () {
              return function (e, n) {
                if (!0 === t.current[T]) return E.apply(e, n);
                if (e[o]) return E.apply(e, n);
                var r = { target: e, url: e[u], isPeriodic: !1, args: n, aborted: !1 },
                  a = h('XMLHttpRequest.send', S, r, O, P);
                e && !0 === e[l] && !r.aborted && a.state === m && a.invoke();
              };
            }),
            w = j(f, 'abort', function () {
              return function (e, n) {
                var o = (function a(e) {
                  return e[r];
                })(e);
                if (o && 'string' == typeof o.type) {
                  if (null == o.cancelFn || (o.data && o.data.aborted)) return;
                  o.zone.cancelTask(o);
                } else if (!0 === t.current[b]) return w.apply(e, n);
              };
            });
        }
        function O(e) {
          var n = e.data,
            o = n.target;
          (o[i] = !1), (o[l] = !1);
          var u = o[a];
          p || ((p = o[c]), (v = o[s])), u && v.call(o, _, u);
          var f = (o[a] = function () {
            if (o.readyState === o.DONE)
              if (!n.aborted && o[i] && e.state === m) {
                var r = o[t.__symbol__('loadfalse')];
                if (0 !== o.status && r && r.length > 0) {
                  var a = e.invoke;
                  (e.invoke = function () {
                    for (var r = o[t.__symbol__('loadfalse')], i = 0; i < r.length; i++) r[i] === e && r.splice(i, 1);
                    n.aborted || e.state !== m || a.call(e);
                  }),
                    r.push(e);
                } else e.invoke();
              } else n.aborted || !1 !== o[i] || (o[l] = !0);
          });
          return p.call(o, _, f), o[r] || (o[r] = e), E.apply(o, n.args), (o[i] = !0), e;
        }
        function S() {}
        function P(e) {
          var t = e.data;
          return (t.aborted = !0), w.apply(t.target, t.args);
        }
      })(e);
      var r = d('xhrTask'),
        o = d('xhrSync'),
        a = d('xhrListener'),
        i = d('xhrScheduled'),
        u = d('xhrURL'),
        l = d('xhrErrorBeforeScheduled');
    }),
    Zone.__load_patch('geolocation', function (t) {
      t.navigator &&
        t.navigator.geolocation &&
        (function n(t, r) {
          for (
            var o = t.constructor.name,
              a = function (n) {
                var a = r[n],
                  i = t[a];
                if (i) {
                  if (!m(e(t, a))) return 'continue';
                  t[a] = (function (e) {
                    var t = function () {
                      return e.apply(this, _(arguments, o + '.' + a));
                    };
                    return z(t, e), t;
                  })(i);
                }
              },
              i = 0;
            i < r.length;
            i++
          )
            a(i);
        })(t.navigator.geolocation, ['getCurrentPosition', 'watchPosition']);
    }),
    Zone.__load_patch('PromiseRejectionEvent', function (e, t) {
      function n(t) {
        return function (n) {
          J(e, t).forEach(function (r) {
            var o = e.PromiseRejectionEvent;
            if (o) {
              var a = new o(t, { promise: n.promise, reason: n.rejection });
              r.invoke(a);
            }
          });
        };
      }
      e.PromiseRejectionEvent && ((t[d('unhandledPromiseRejectionHandler')] = n('unhandledrejection')), (t[d('rejectionHandledHandler')] = n('rejectionhandled')));
    });
});
